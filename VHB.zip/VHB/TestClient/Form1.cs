﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using ESRI.ArcGIS.esriSystem;
//using Microsoft.ApplicationInsights;
//using Microsoft.ApplicationInsights.Extensibility;


namespace TestClient {
	/*
	External deployment process
		Settings file:
			SOE_GE = https://gistest.vhb.com/arcgis/rest/services/AlbanyGIS/MHD_DEV/MapServer/exts/GeocodeSOE_external/
			SOE_TE = https://gistest.vhb.com/arcgis/rest/services/AlbanyGIS/MHD_DEV/MapServer/exts/GeocodeSOE_internal/
		GeocodeSOE_internal.cs and GeocodeSOE_external.cs:
			swap dbConnCfg to external

	Internal testing
		Settings file:
			SOE_GE = https://z7414.vhb.com:6443/arcgis/rest/services/SampleWorldCities/MapServer/exts/GeocodeSOE_external/
			SOE_TE = https://z7414.vhb.com:6443/arcgis/rest/services/SampleWorldCities/MapServer/exts/GeocodeSOE_internal/
		GeocodeSOE_internal.cs and GeocodeSOE_external.cs:
			swap dbConnCfg to internal

	https://massdotcrashgeocoder-test.vhb.com/geo/rest/services/SampleWorldCities/MapServer/exts/GeocodeSOE_external/
	https://massdotcrashgeocoder-test.vhb.com/geo/rest/services/SampleWorldCities/MapServer/exts/GeocodeSOE_internal/

	*/
	public struct AGSTOKEN {
		public string token;
		public long expires;
	}

	public partial class Form1 : Form {
		//TelemetryConfiguration.Active.InstrumentationKey = "c40a2f67-0601-48c0-bed8-47338fbd5872";
		//TelemetryClient aiClient = new TelemetryClient();
		//aiClient.TrackEvent("Geocoder Test Client startup");
		GeocodeEngine.GEngine GE = null;
		GeocodeEngine.TEngine TE = null;
		string dbConnStrCfg = "";
		string dbConnStrGDB = "";
		bool externalMode = false;
		bool webMode = false;
		bool webMode2 = false;
		string token = "";
		List<GeocodeEngine.settingItem> Settings;

		// moved from Geodatabase
		public string AObind = "";
		private IAoInitialize AOinit;
		private esriLicenseStatus AOstatus = 0;
		public bool getAOLicense() {
			try {
				if (AObind != "") return true;
				if (AObind == "" && ESRI.ArcGIS.RuntimeManager.Bind(ESRI.ArcGIS.ProductCode.Engine)) { AObind = "engine"; }
				if (AObind == "" && ESRI.ArcGIS.RuntimeManager.Bind(ESRI.ArcGIS.ProductCode.Desktop)) { AObind = "desktop"; }
				AOinit = new AoInitialize();
				esriLicenseProductCode product = esriLicenseProductCode.esriLicenseProductCodeBasic;
				product = esriLicenseProductCode.esriLicenseProductCodeAdvanced;
				product = esriLicenseProductCode.esriLicenseProductCodeBasic;
				if (AObind == "engine") product = esriLicenseProductCode.esriLicenseProductCodeEngine;
				if (AOinit.IsProductCodeAvailable(product) == esriLicenseStatus.esriLicenseAvailable) { AOstatus = AOinit.Initialize(product); }
				switch (AOstatus) {  //failure modes
					case 0:
					case esriLicenseStatus.esriLicenseFailure:
					case esriLicenseStatus.esriLicenseNotInitialized:
					case esriLicenseStatus.esriLicenseNotLicensed:
					case esriLicenseStatus.esriLicenseUnavailable:
					case esriLicenseStatus.esriLicenseUntrusted:
						AObind = "INVALID";
						return false;
						//break;
				}
				return true;
			} catch (Exception) {
				AObind = "INVALID";
				return false;
			}
		}

		//
		public Form1() {
			getAOLicense();//:10-23
			try {
				InitializeComponent();
				/*
				SELECT TOP (1000) [OBJECTID]
      ,[NAME]
      ,[MUNI_TYPE]
      ,[MUNITYCODE]
      ,[COUNTY]
      ,[GNIS_ID]
      ,[FIPS_CODE]
      ,[SWIS]
      ,[POP1990]
      ,[POP2000]
      ,[POP2010]
      ,[POP2020]
      ,[DOS_LL]
      ,[DOSLL_DATE]
      ,[MAP_SYMBOL]
      ,[CALC_SQ_MI]
      ,[DATEMOD]
      ,[Shape]
      ,[GDB_GEOMATTR_DATA]
  FROM [CLEAR_REFERENCE].[GIS].[CITYTOWN]
				*/
				//tabControl2.SelectTab("tabAD");
				Version v = System.Reflection.Assembly.GetAssembly(typeof(Form1)).GetName().Version;
				this.Text += " : " + v.ToString();
				System.Net.ServicePointManager.ServerCertificateValidationCallback += this.ignoreCertError;
				//this.getToken();//:10-23
				/*
				//set method bitmask for input controls
				txtAddrNum.Tag = GeocodeEngine.LUT.Bits.Address;
				txtCoordX.Tag = GeocodeEngine.LUT.Bits.Coordinates + GeocodeEngine.LUT.Bits.OffIntersection;
				txtCoordY.Tag = GeocodeEngine.LUT.Bits.Coordinates + GeocodeEngine.LUT.Bits.OffIntersection;
				txtDir1.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Address + GeocodeEngine.LUT.Bits.Exit + GeocodeEngine.LUT.Bits.MileMarker;
				txtDir2.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection;
				txtDir3.Tag = GeocodeEngine.LUT.Bits.AtIntersection;
				txtExitNum.Tag = GeocodeEngine.LUT.Bits.Exit;
				txtLandmark.Tag = GeocodeEngine.LUT.Bits.Landmark + GeocodeEngine.LUT.Bits.Rotary;
				txtMile.Tag = GeocodeEngine.LUT.Bits.MileMarker;
				txtOffDir.Tag = GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.MileMarker;
				txtOffDist.Tag = GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Exit + GeocodeEngine.LUT.Bits.MileMarker;
				txtRoad1.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Address + GeocodeEngine.LUT.Bits.Landmark + GeocodeEngine.LUT.Bits.Rotary;
				txtRoad2.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Rotary;
				txtRoad3.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.Rotary;
				txtRoute1.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Address + GeocodeEngine.LUT.Bits.Exit + GeocodeEngine.LUT.Bits.MileMarker + GeocodeEngine.LUT.Bits.Landmark + GeocodeEngine.LUT.Bits.Rotary;
				txtRoute2.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Rotary;
				txtRoute3.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.Rotary;
				txtCountyCode.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Address + GeocodeEngine.LUT.Bits.Landmark;
				txtTownCode.Tag = GeocodeEngine.LUT.Bits.AtIntersection + GeocodeEngine.LUT.Bits.OffIntersection + GeocodeEngine.LUT.Bits.Address + GeocodeEngine.LUT.Bits.Landmark;
				//apply bitmask
				this.chkMethod_CheckedChanged(null, null);
				*/
				this.dbConnStrCfg = Settings1.Default.dbConnCfg;
				this.dbConnStrGDB = Settings1.Default.dbConnGDB;

				this.webMode = (Settings1.Default.connectionMode == "web");
				this.webMode2 = (Settings1.Default.connectionMode == "web2");
				List<GeocodeEngine.lutItem> items;

				if (this.webMode || this.webMode2) {
					//set web mode settings
					chkMethodAddr.Checked = true;
					chkMethodAddr.Enabled = false;
					chkMethodAtInt.Checked = true;
					chkMethodAtInt.Enabled = false;
					chkMethodCoords.Checked = true;
					chkMethodCoords.Enabled = false;
					chkMethodExit.Checked = true;
					chkMethodExit.Enabled = false;
					chkMethodLmrk.Checked = true;
					chkMethodLmrk.Enabled = false;
					chkMethodMile.Checked = true;
					chkMethodMile.Enabled = false;
					chkMethodOffInt.Checked = true;
					chkMethodOffInt.Enabled = false;
					chkMethodRM.Checked = true;
					chkMethodRM.Enabled = false;
					//txtCrashNum.Enabled = false;
					//btnTELoadCrashNum.Enabled = false;
					//cbxCfgGrp.Enabled = false;
					//btnReload.Enabled = false;
					//btnSave.Enabled = false;
					this.dbConnStrCfg = "";
					this.dbConnStrGDB = "";
					string json;
					//towns
					cbxTown.Items.Clear();
					json = getUrl(Settings1.Default.SOE_TE + "GetLUT?f=json&table=TOWNS&token=" + this.token);
					items = JsonConvert.DeserializeObject<List<GeocodeEngine.lutItem>>(json);
					foreach (GeocodeEngine.lutItem item in items) { cbxTown.Items.Add(item); }
					//cbxJuntionType.Items.Clear();
					//json = getUrl(Settings1.Default.SOE_TE + "GetLUT?f=json&table=JNCT_TYPE&token=" + this.token);
					//items = JsonConvert.DeserializeObject<List<GeocodeEngine.lutItem>>(json);
					//foreach (GeocodeEngine.lutItem item in items) { cbxJuntionType.Items.Add(item); }
					//cbxFacilityType.Items.Clear();
					//json = getUrl(Settings1.Default.SOE_TE + "GetLUT?f=json&table=ROAD_TYPE&token=" + this.token);
					//items = JsonConvert.DeserializeObject<List<GeocodeEngine.lutItem>>(json);
					//foreach (GeocodeEngine.lutItem item in items) { cbxFacilityType.Items.Add(item); }
					//cbxControlType.Items.Clear();
					//json = getUrl(Settings1.Default.SOE_TE + "GetLUT?f=json&table=CNTRL_DEVC&token=" + this.token);
					//items = JsonConvert.DeserializeObject<List<GeocodeEngine.lutItem>>(json);
					//foreach (GeocodeEngine.lutItem item in items) { cbxControlType.Items.Add(item); }
					//cbxAccessCtrl.Items.Clear();
					//json = getUrl(Settings1.Default.SOE_TE + "GetLUT?f=json&table=ACCESS_CTRL&token=" + this.token);
					//items = JsonConvert.DeserializeObject<List<GeocodeEngine.lutItem>>(json);
					//foreach (GeocodeEngine.lutItem item in items) { cbxAccessCtrl.Items.Add(item); }
					//cbxControlFunc.Items.Clear();
					//json = getUrl(Settings1.Default.SOE_TE + "GetLUT?f=json&table=CNTRL_FUNC&token=" + this.token);
					//items = JsonConvert.DeserializeObject<List<GeocodeEngine.lutItem>>(json);
					//foreach (GeocodeEngine.lutItem item in items) { cbxControlFunc.Items.Add(item); }
					//cbxPoliceDept.Items.Clear();
					//json = getUrl(Settings1.Default.SOE_TE + "GetLUT?f=json&table=AGENCY&token=" + this.token);
					//items = JsonConvert.DeserializeObject<List<GeocodeEngine.lutItem>>(json);
					//foreach (GeocodeEngine.lutItem item in items) { cbxPoliceDept.Items.Add(item); }
					//TODO: other cbx
					json = getUrl(Settings1.Default.SOE_TE + "ReadSettings?f=json&Password=agis2447agis2447&token=" + this.token);
					this.Settings = JsonConvert.DeserializeObject<List<GeocodeEngine.settingItem>>(json);
				} else {
					this.GE = new GeocodeEngine.GEngine(this.dbConnStrCfg, true);
					this.TE = new GeocodeEngine.TEngine(this.dbConnStrCfg, true);
					if (externalMode) {
						// this block is for delivery, obscures connection string
						// hard code db connection for delivery
						int[] A = { 78, 21, 12, 84, 91, 37, 2, 118, 8, 127, 106, 98, 14, 93, 72, 34, 37, 120, 111, 76, 53, 10, 124, 106, 98, 51, 117, 116, 94, 74, 22, 91, 53, 24, 0, 106, 11, 2, 102, 56, 49, 40, 127, 80, 35, 53, 122, 73, 3, 118, 61, 24, 28, 71, 98, 87, 17, 66, 13, 20, 65, 102, 43, 18, 56, 62, 52, 113, 115, 50, 6, 83, 84, 96, 9, 72, 73, 13, 106, 43, 57, 69, 52, 63, 20, 98, 79, 100, 55, 68, 110, 84, 50, 55, 22, 111, 119, 126, 111, 118, 77, 121, 37, 109, 46, 61, 121, 40, 3, 11, 89, 12, 122, 72, 12, 28, 30, 122, 14, 85, 70, 61, 111, 11, 48, 95, 69, 120, 100, 108, 21 };
						int[] B = { 29, 112, 126, 34, 62, 87, 63, 0, 96, 29, 14, 7, 120, 41, 45, 81, 81, 86, 11, 45, 65, 107, 30, 11, 17, 86, 91, 3, 55, 36, 114, 52, 66, 107, 46, 4, 110, 118, 93, 24, 117, 73, 11, 49, 65, 84, 9, 44, 62, 59, 117, 92, 67, 3, 39, 1, 78, 5, 73, 86, 122, 70, 126, 97, 93, 76, 20, 56, 23, 15, 75, 27, 16, 37, 95, 23, 28, 94, 47, 121, 2, 101, 100, 94, 103, 17, 56, 11, 69, 32, 83, 50, 85, 114, 68, 75, 65, 74, 5, 77, 109, 52, 80, 1, 90, 84, 9, 68, 102, 74, 58, 120, 19, 62, 105, 78, 123, 9, 123, 57, 50, 110, 10, 127, 67, 98, 17, 10, 17, 9, 46 };
						//this.dbConnStrCfg = "Server=vhbdevtest.database.windows.net; Database=MHD_DEV_GDB; User Id=MHDEV_USER; Password=fgER$64j; MultipleActiveResultSets=True;";
						this.dbConnStrCfg = "";
						for (int i = 0; i < 131; i++) { this.dbConnStrCfg += (char)(A[i] ^ B[i]); } //xor ints to produce string
					}
					//fill county/town boxes
					GE.GDB.DMgr.selectDataVersion(DateTime.Now);
					cbxTown.Items.Clear();
					cbxCounty.Items.Clear();
					using (SqlConnection dbConn = new SqlConnection(GeocodeEngine.Config.dbConnGDB)) {
						dbConn.Open();
						string lbl, val, sql = "select COUNTY, NAME, CTVR as MUNITYCODE, FIPS_CODE from " + GE.GDB.DMgr.tblTowns + " order by FIPS_CODE";
						GeocodeEngine.lutItem item;
						SqlDataReader R = new SqlCommand(sql, dbConn).ExecuteReader();
						while (R.Read()) {
							val = R["FIPS_CODE"].ToString();
							lbl = R["COUNTY"].ToString() + "/" + R["NAME"].ToString();
							if (R["MUNITYCODE"].ToString() == "1") lbl = R["COUNTY"].ToString() + "/[" + R["NAME"].ToString() + "]";
							item = new GeocodeEngine.lutItem(val, lbl);
							cbxTown.Items.Add(item);
						}
						R.Close();
						sql = "select NAME, FIPS_CODE from GIS.COUNTY order by NAME";
						R = new SqlCommand(sql, dbConn).ExecuteReader();
						while (R.Read()) {
							lbl = R["NAME"].ToString();
							val = lbl;// R["FIPS_CODE"].ToString();
							item = new GeocodeEngine.lutItem(val, lbl);
							cbxCounty.Items.Add(item);
						}
						R.Close();
						dbConn.Close();
					}

					/*
					cbxTown.Items.Clear();
					items = this.TE.getLUTitems("TOWNS");
					foreach (GeocodeEngine.lutItem item in items) { cbxTown.Items.Add(item); }
					cbxJuntionType.Items.Clear();
					items = this.TE.getLUTitems("JNCT_TYPE");
					foreach (GeocodeEngine.lutItem item in items) { cbxJuntionType.Items.Add(item); }
					cbxFacilityType.Items.Clear();
					items = this.TE.getLUTitems("ROAD_TYPE");
					foreach (GeocodeEngine.lutItem item in items) { cbxFacilityType.Items.Add(item); }
					cbxControlType.Items.Clear();
					items = this.TE.getLUTitems("CNTRL_DEVC");
					foreach (GeocodeEngine.lutItem item in items) { cbxControlType.Items.Add(item); }
					cbxAccessCtrl.Items.Clear();
					items = this.TE.getLUTitems("ACCESS_CTRL");
					foreach (GeocodeEngine.lutItem item in items) { cbxAccessCtrl.Items.Add(item); }
					cbxControlFunc.Items.Clear();
					items = this.TE.getLUTitems("CNTRL_FUNC");
					foreach (GeocodeEngine.lutItem item in items) { cbxControlFunc.Items.Add(item); }
					cbxPoliceDept.Items.Clear();
					items = this.TE.getLUTitems("AGENCY");
					foreach (GeocodeEngine.lutItem item in items) { cbxPoliceDept.Items.Add(item); }
					*/
					//this.Settings = this.TE.readSettings();//:10-23
				}
				/*
				// fill cbxCfgGrp
				List<string> grps = new List<string>();
				foreach (GeocodeEngine.settingItem item in this.Settings) {
					if (!grps.Contains(item.Grp)) grps.Add(item.Grp);
				}
				cbxCfgGrp.Items.Clear();
				foreach (string item in grps) { cbxCfgGrp.Items.Add(item); }
				*/
				// fill direction lists
				List<ComboBox> LCbx = new List<ComboBox>();
				//LCbx.Add(cbxAIRouteDir1);
				//LCbx.Add(cbxAIRouteDir2);
				//LCbx.Add(cbxAIRouteDir3);
				//LCbx.Add(cbxOIRouteDir1);
				//LCbx.Add(cbxOIRouteDir2);
				LCbx.Add(cbxOIDir);
				//LCbx.Add(cbxMMRouteDir);
				//LCbx.Add(cbxMMDir);
				//LCbx.Add(cbxEXRouteDir);
				//LCbx.Add(cbxEXDir);
				//LCbx.Add(cbxLMDir);
				string[] dirs = ",N,E,S,W".Split(',');
				foreach (ComboBox cbx in LCbx) {
					cbx.Items.Clear();
					foreach (string d in dirs) {
						cbx.Items.Add(d);
					}
				}
				cbxOIDir.SelectedIndex = 0;
				cbxOffUnit.Items.Clear();
				cbxOffUnit.Items.Add("Feet");
				cbxOffUnit.Items.Add("Meters");
				cbxOffUnit.Items.Add("Miles");
				cbxOffUnit.SelectedIndex = 0;
				cbxOffOpt.Items.Clear();
				cbxOffOpt.Items.Add("0 None");
				cbxOffOpt.Items.Add("1 Street");
				cbxOffOpt.Items.Add("2 Exit");
				cbxOffOpt.Items.Add("3 Milepost");
				cbxOffOpt.Items.Add("4 RefMark");
				cbxOffOpt.Items.Add("5 Landmark");
				cbxOffOpt.SelectedIndex = 0;
				lblStatus.Text = "Status: " + getGEngineStatus();
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			}
		}
		~Form1() {
			//AOinit.Shutdown();//:10-23
		}
		public string getGEngineStatus() {
			//if (this.GE == null) {//:10-23
			//	return "WEB MODE";
			//} else {
			//	return this.GE.GetStatus();
			//}
			return " offline";
		}

		public string getToken() {
			////get from database
			//using(SqlConnection dbConn=new SqlConnection(this.dbConnStrCfg)) {
			//	dbConn.Open();
			//	string sql = "select Value from ADMIN.GEOCODER_SETTINGS where Grp='Batch' and Name='Token'";
			//	this.token = new SqlCommand(sql, dbConn).ExecuteScalar().ToString();
			//	dbConn.Close();
			//}
			
			//get from url
			if (Settings1.Default.AGSuser != "") {
				Dictionary<string, string> fields = new Dictionary<string, string> { { "f", "json" }, { "username", Settings1.Default.AGSuser }, { "password", Settings1.Default.AGSpwd }, { "client", "requestip" }, { "expiration", "525600" } };
				//https://gistest.vhb.com/arcgis/rest/services/AlbanyGIS/MHD_DEV/MapServer/exts/GeocodeSOE_external/
				int i = Settings1.Default.SOE_TE.IndexOf("/rest/");
				string url = Settings1.Default.SOE_TE.Substring(0, i) + "/tokens/generateToken";
				string json = postUrl(url, fields);
				AGSTOKEN T = JsonConvert.DeserializeObject<AGSTOKEN>(json);
				this.token = T.token;
			}
			
			return this.token;
		}

	public string getUrl(string url) {
			string json = "";
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
			req.Referer = "https://www.vhb.com/";
			req.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip;
			using (HttpWebResponse rep = (HttpWebResponse)req.GetResponse())
			using (Stream stream = rep.GetResponseStream())
			using (StreamReader SR = new StreamReader(stream)) {
				json = SR.ReadToEnd();
			}
			return json;
		}
		public string postUrl(string url, Dictionary<string, string> fields) {
			string json = "";
			string postdata = "";
			foreach (string name in fields.Keys) {
				if (postdata != "") postdata += "&";
				postdata += WebUtility.UrlEncode(name) + "=" + WebUtility.UrlEncode(fields[name]);
			}
			byte[] postBytes = new ASCIIEncoding().GetBytes(postdata);
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
			req.Method = "POST";
			req.ContentType = "application/x-www-form-urlencoded";
			req.ContentLength = postBytes.Length;
			using (Stream stream = req.GetRequestStream()) {
				stream.Write(postBytes, 0, postBytes.Length);
			}
			using (HttpWebResponse rep = (HttpWebResponse)req.GetResponse()) {
				using (Stream stream = rep.GetResponseStream()) {
					using (StreamReader SR = new StreamReader(stream)) {
						json = SR.ReadToEnd();
					}
				}
			}
			return json;
		}
		private bool ignoreCertError(object sender, System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors errs) {
			return true;
		}

		private GeocodeEngine.GeocodeInput readInputs() {
			//get inputs
			GeocodeEngine.GeocodeInput Params = new GeocodeEngine.GeocodeInput();
			Params.CrashDate = txtCrashDate.Text;
			if (txtCrashNum.Text != null && txtCrashNum.Text.Length > 0) Params.CrashNum = (txtCrashNum.Text);
			//Params.AccessCtrl = ValOrNull(((cbxAccessCtrl.SelectedItem ?? new GeocodeEngine.lutItem()) as GeocodeEngine.lutItem).Value);
			Params.AI_RoadName1 = ValOrNull(txtAIRoadName1.Text);
			Params.AI_RoadName2 = ValOrNull(txtAIRoadName2.Text);
			//Params.AtInt = chkAtInt.Checked;
			//Params.AI_RoadName3 = ValOrNull(txtAIRoadName3.Text);
			//Params.AI_RouteDir1 = ValOrNull(cbxAIRouteDir1.Text);
			//Params.AI_RouteDir2 = ValOrNull(cbxAIRouteDir2.Text);
			//Params.AI_RouteDir3 = ValOrNull(cbxAIRouteDir3.Text);
			//Params.AI_RouteNum1 = ValOrNull(txtAIRouteNum1.Text);
			//Params.AI_RouteNum2 = ValOrNull(txtAIRouteNum2.Text);
			//Params.AI_RouteNum3 = ValOrNull(txtAIRouteNum3.Text);
			//Params.ControlFunc = ValOrNull(((cbxControlFunc.SelectedItem ?? new GeocodeEngine.lutItem()) as GeocodeEngine.lutItem).Value);
			//Params.ControlType = ValOrNull(((cbxControlType.SelectedItem ?? new GeocodeEngine.lutItem()) as GeocodeEngine.lutItem).Value);
			//Params.EX_Dir = ValOrNull(cbxEXDir.Text);
			//Params.EX_Dist = GeocodeEngine.Utils.intParse(txtEXDist.Text);
			Params.EX_Exit = ValOrNull(txtEXExit.Text);
			//Params.EX_RouteDir = ValOrNull(cbxEXRouteDir.Text);
			Params.EX_RouteNum = ValOrNull(txtAIRoadName1.Text);
			//Params.FacilityType = ValOrNull(((cbxFacilityType.SelectedItem ?? new GeocodeEngine.lutItem()) as GeocodeEngine.lutItem).Value);
			decimal tmpD;
			Params.GPS_X = null;
			if (decimal.TryParse(txtGPSX.Text, out tmpD)) Params.GPS_X = tmpD;
			Params.GPS_Y = null;
			if (decimal.TryParse(txtGPSY.Text, out tmpD)) Params.GPS_Y = tmpD;
			//Params.JunctionType = ValOrNull(((cbxJuntionType.SelectedItem ?? new GeocodeEngine.lutItem()) as GeocodeEngine.lutItem).Value);
			//Params.LM_Dir = ValOrNull(cbxLMDir.Text);
			//Params.LM_Dist = GeocodeEngine.Utils.intParse(txtLMDist.Text);
			Params.LM_Landmark = ValOrNull(txtLMLandmark.Text);
			//Params.RO_Rotary = ValOrNull(txtRORotary.Text);
			//Params.MM_Dir = ValOrNull(cbxMMDir.Text);
			//Params.MM_Dist = GeocodeEngine.Utils.intParse(txtMMDist.Text);
			Params.MM_Mile = GeocodeEngine.Utils.decimalParse(txtMMMile.Text);
			//Params.MM_RouteDir = ValOrNull(cbxMMRouteDir.Text);
			Params.MM_RouteNum = ValOrNull(txtAIRoadName1.Text);
			Params.OI_AddrNum = ValOrNull(txtOIAddrNum.Text);
			Params.Offset_Dir = ValOrNull(cbxOIDir.Text);
			Params.Offset_Dist = GeocodeEngine.Utils.decimalParse(txtOIDist.Text);
			string offUnits = ValOrNull(cbxOffUnit.Text) ?? "";
			if (offUnits.ToUpper() == "FEET") Params.Offset_Dist = (decimal)GeocodeEngine.Utils.FeetToMeters(Params.Offset_Dist);
			if (offUnits.ToUpper() == "MILES") Params.Offset_Dist = (decimal)GeocodeEngine.Utils.MilesToMeters(Params.Offset_Dist);
			Params.Offset_Option = int.Parse(cbxOffOpt.Text.Substring(0, 1));
			Params.OI_RoadName1 = ValOrNull(txtAIRoadName1.Text);
			//if (Params.OI_RoadName1 == null) Params.OI_RoadName1 = ValOrNull(txtADRoadName.Text);
			Params.OI_RoadName2 = ValOrNull(txtOIRoadName2.Text);
			//Params.OI_RouteDir1 = ValOrNull(cbxOIRouteDir1.Text);
			//Params.OI_RouteDir2 = ValOrNull(cbxOIRouteDir2.Text);
			//Params.OI_RouteNum1 = ValOrNull(txtOIRouteNum1.Text);
			//Params.OI_RouteNum2 = ValOrNull(txtOIRouteNum2.Text);
			//Params.RM_Dir = ValOrNull(cbxRMDir.Text);
			//Params.RM_Dist = GeocodeEngine.Utils.intParse(txtRMDist.Text);
			Params.RM_RefMark = ValOrNull(txtRMRefMark.Text);
			//Params.PoliceDept = ValOrNull(((cbxPoliceDept.SelectedItem ?? new GeocodeEngine.lutItem()) as GeocodeEngine.lutItem).Value);
			//Params.SpeedLimit = ValOrNull(txtSpeedLimit.Text);
			//Params.TownCode = cbxTown.Text.Split(':')[0];
			if (cbxTown.SelectedItem != null) {
				Params.TownFIPS = (cbxTown.SelectedItem as GeocodeEngine.lutItem).Value;
				string tmp = (cbxTown.SelectedItem as GeocodeEngine.lutItem).Label;
				Params.TownName = tmp.Split('/')[1];
			}
			//Params.CountyName = tmp.Split('/')[0];
			Params.CountyName = (cbxCounty.SelectedItem as GeocodeEngine.lutItem).Label;
			Params.ZipCode = txtZIP.Text;
			Params.NonPublicWay = (chkParking.Checked ? 1 : 0);
			//Params.roadName1 = txtRoute1.Text;
			//Params.direction1 = txtDir1.Text;
			//Params.mileMarker = decimal.Parse(txtMile.Text);
			//TODO: other fields
			return Params;
		}
		public void displayResults(GeocodeEngine.GeocodeOutput Results) {
			txtOutput.Text = "";
			//if (this.webMode) txtOutput.Text += "URL: " + url + "\r\n";
			txtOutput.Text += "CANDIDATES: " + Results.Candidates.Count.ToString() + "\r\n";
			int i;
			for (i = 0; i < Results.Candidates.Count; i++) {
				//txtOutput.Text += JsonConvert.SerializeObject(Results.Candidates[i]) + "\r\n";
				txtOutput.Text += JsonConvert.SerializeObject(Results.Candidates[i]) + "\r\n";
			}
			txtOutput.Text += "ERRORS: " + Results.Errors.Count.ToString() + "\r\n";
			for (i = 0; i < Results.Errors.Count; i++) {
				txtOutput.Text += Results.Errors[i].toString() + "\r\n";
			}
			if (Results.Log != null && Results.Log.Count > 0) {
				txtOutput.Text += "LOG: " + Results.Log.Count.ToString() + "\r\n";
				for (i = 0; i < Results.Log.Count; i++) {
					txtOutput.Text += Results.Log[i].toString() + "\r\n";
				}
			}
			if (Results.Warnings.Count > 0) {
				txtOutput.Text += "WARNINGS: " + Results.Warnings.Count.ToString() + "\r\n";
				for (i = 0; i < Results.Warnings.Count; i++) {
					txtOutput.Text += Results.Warnings[i].toString() + "\r\n";
				}
			}
			if (Results.Timings.Count > 0) {
				txtOutput.Text += "TIMINGS: " + Results.Timings.Count.ToString() + "\r\n";
				for (i = 0; i < Results.Timings.Count; i++) {
					txtOutput.Text += Results.Timings[i].toString() + "\r\n";
				}
			}
			txtOutput.Text += "\r\n";
			txtOutput.Text += "INPUT: \r\n";
			txtOutput.Text += JsonConvert.SerializeObject(Results.Input) + "\r\n";
		}
		string ValOrNull(string txt) {
			if (txt == "") return null;
			return txt;
		}
		private int getMethods() {
			//get the bitmask of the selected methods
			int methods = 0;
			methods += (chkMethodAddr.Checked ? GeocodeEngine.LUT.Bits.Address : 0);
			methods += (chkMethodAtInt.Checked ? GeocodeEngine.LUT.Bits.AtIntersection : 0);
			methods += (chkMethodCoords.Checked ? GeocodeEngine.LUT.Bits.Coordinates : 0);
			methods += (chkMethodExit.Checked ? GeocodeEngine.LUT.Bits.Exit : 0);
			methods += (chkMethodLmrk.Checked ? GeocodeEngine.LUT.Bits.Landmark : 0);
			methods += (chkMethodMile.Checked ? GeocodeEngine.LUT.Bits.MileMarker : 0);
			methods += (chkMethodOffInt.Checked ? GeocodeEngine.LUT.Bits.OffIntersection : 0);
			methods += (chkMethodRM.Checked ? GeocodeEngine.LUT.Bits.RefMarker : 0);
			//methods += (chkMethodRot.Checked ? GeocodeEngine.LUT.Bits.Rotary : 0);
			return methods;
		}

		private string paramsToQuery(GeocodeEngine.GeocodeInput Params) {
			string url = "";
			url += "&TownCode=" + Params.TownFIPS;
			url += "&Road1=" + (Params.AI_RoadName1 ?? Params.OI_RoadName1 ?? "");
			url += "&RouteNum1=" + (Params.AI_RouteNum1 ?? Params.OI_RouteNum1 ?? Params.MM_RouteNum ?? Params.EX_RouteNum ?? "");
			url += "&RouteDir1=" + (Params.AI_RouteDir1 ?? Params.OI_RouteDir1 ?? Params.MM_RouteDir ?? Params.EX_RouteDir ?? "");
			url += "&Road2=" + (Params.AI_RoadName2 ?? Params.OI_RoadName2 ?? "");
			url += "&RouteNum2=" + (Params.AI_RouteNum2 ?? Params.OI_RouteNum2 ?? "");
			url += "&RouteDir2=" + (Params.AI_RouteDir2 ?? Params.OI_RouteDir2 ?? "");
			url += "&Road3=" + (Params.AI_RoadName3 ?? "");
			url += "&RoueNum3=" + (Params.AI_RouteNum3 ?? "");
			url += "&RouteDir3=" + (Params.AI_RouteDir3 ?? "");
			url += "&Address=" + (Params.OI_AddrNum ?? "");
			url += "&ExitNum=" + (Params.EX_Exit ?? "");
			url += "&MileMark=" + Params.MM_Mile;
			url += "&Landmark=" + (Params.LM_Landmark ?? "");
			//url += "&Rotary=" + (Params.RO_Rotary ?? "");
			//url += "&OffsetDir=" + (Params.OI_Dir ?? Params.MM_Dir ?? Params.LM_Dir ?? Params.EX_Dir ?? "");
			decimal? dist = (Params.Offset_Dist ?? -1);
			url += "&OffsetDist=" + (dist < 0 ? "" : dist.ToString());
			url += "&CoordX=" + Params.GPS_X;
			url += "&CoordY=" + Params.GPS_Y;
			url += "&token=" + this.token;
			return url;
		}

		private string paramsToQuery2(GeocodeEngine.GeocodeInput Params) {
			string url = "";
			url += "&TownCode=" + Params.TownFIPS;
			url += "&AtInt_Road1=" + (Params.AI_RoadName1 ?? "");
			url += "&AtInt_RouteNum1=" + (Params.AI_RouteNum1 ?? "");
			url += "&AtInt_RouteDir1=" + (Params.AI_RouteDir1 ?? "");
			url += "&AtInt_Road2=" + (Params.AI_RoadName2 ?? "");
			url += "&AtInt_RouteNum2=" + (Params.AI_RouteNum2 ?? "");
			url += "&AtInt_RouteDir2=" + (Params.AI_RouteDir2 ?? "");
			url += "&AtInt_Road3=" + (Params.AI_RoadName3 ?? "");
			url += "&AtInt_RoueNum3=" + (Params.AI_RouteNum3 ?? "");
			url += "&AtInt_RouteDir3=" + (Params.AI_RouteDir3 ?? "");
			url += "&OffInt_Road1=" + (Params.OI_RoadName1 ?? "");
			url += "&OffInt_RouteNum1=" + (Params.OI_RouteNum1 ?? "");
			url += "&OffInt_RouteDir1=" + (Params.OI_RouteDir1 ?? "");
			url += "&OffInt_Road2=" + (Params.OI_RoadName2 ?? "");
			url += "&OffInt_RouteNum2=" + (Params.OI_RouteNum2 ?? "");
			url += "&OffInt_RouteDir2=" + (Params.OI_RouteDir2 ?? "");
			url += "&OffInt_OffsetDir=" + (Params.Offset_Dir ?? "");
			url += "&OffInt_OffsetDist=" + (Params.Offset_Dist != null ? Params.Offset_Dist.ToString() : "");
			url += "&Address=" + (Params.OI_AddrNum ?? "");
			url += "&Exit_RouteNum=" + (Params.EX_RouteNum ?? "");
			url += "&Exit_RouteDir=" + (Params.EX_RouteDir ?? "");
			url += "&ExitNum=" + (Params.EX_Exit ?? "");
			//url += "&Exit_OffsetDir=" + (Params.EX_Dir ?? "");
			//url += "&Exit_OffsetDist=" + (Params.EX_Dist != null ? Params.EX_Dist.ToString() : "");
			url += "&Mile_RouteNum=" + (Params.MM_RouteNum ?? "");
			url += "&Mile_RouteDir=" + (Params.MM_RouteDir ?? "");
			url += "&MileMark=" + Params.MM_Mile;
			//url += "&Mile_OffsetDir=" + (Params.MM_Dir ?? "");
			//url += "&Mile_OffsetDist=" + (Params.MM_Dist != null ? Params.MM_Dist.ToString() : "");
			url += "&Landmark=" + (Params.LM_Landmark ?? "");
			//url += "&Landmark_OffsetDir=" + (Params.LM_Dir ?? "");
			//url += "&Landmark_OffsetDist=" + (Params.LM_Dist != null ? Params.LM_Dist.ToString() : "");
			//url += "&Rotary=" + (Params.RO_Rotary ?? "");
			url += "&CoordX=" + Params.GPS_X;
			url += "&CoordY=" + Params.GPS_Y;
			//url += "&FacilityTypeCode=" + Params.FacilityType;
			//url += "&JunctionTypeCode=" + Params.JunctionType;
			//url += "&ControlTypeCode=" + Params.ControlType;
			//url += "&ControlFuncCode=" + Params.ControlFunc;
			//url += "&AccessCtrlCode=" + Params.AccessCtrl;
			//url += "&PoliceDeptId=" + Params.PoliceDept;
			//url += "&SpeedLimit=" + Params.SpeedLimit;
			url += "&token=" + this.token;
			return url;
		}

		////////////////////////////////////////////////////////////
		// geocode tab

		private void btnGeocode_Click(object sender, EventArgs e) {
			DateTime tme0 = DateTime.Now;
			try {
				txtOutput.Text = "";
				btnGeocode.Enabled = false;
				btnTEGeocode.Enabled = false;
				tabControl1.Enabled = false;
				Application.UseWaitCursor = true;
				Application.DoEvents();
				GeocodeEngine.GeocodeInput Params = this.readInputs();
				GeocodeEngine.GeocodeOutput Results;

				string url = "";
				if (this.webMode) {
					//http://gistest.vhb.com/arcgis/rest/services/AlbanyGIS/MHD_DEV/MapServer/exts/GeocodeSOE_external/Geocode?TownCode=&Road1=&RouteNum1=&RouteDir1=&Road2=&RouteNum2=&RouteDir2=&Road3=&RouteNum3=&RouteDir3=&Address=&ExitNum=&MileMark=&Landmark=&OffsetDir=&OffsetDist=&CoordX=&CoordY=&f=pjson
					url = Settings1.Default.SOE_GE + "Geocode?f=pjson";
					url += paramsToQuery(Params);
					string json = getUrl(url);
					Results = JsonConvert.DeserializeObject<GeocodeEngine.GeocodeOutput>(json);
				} else if (this.webMode2) {
					url = Settings1.Default.SOE_GE + "Geocode2?f=pjson";
					url += paramsToQuery2(Params);
					string json = getUrl(url);
					Results = JsonConvert.DeserializeObject<GeocodeEngine.GeocodeOutput>(json);
				} else {	//local mode
					int methods = this.getMethods();
					//send to engine
					//if (this.GE == null) this.GE = new GeocodeEngine.GEngine(Settings1.Default.dbConnCfg);
					//GeocodeEngine.GEngine GE = new GeocodeEngine.GEngine(Settings1.Default.dbConnCfg);
					Results = GE.Geocode(Params, methods);
				}
				//display output
				this.displayResults(Results);

			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			} finally {
				btnGeocode.Enabled = true;
				btnTEGeocode.Enabled = true;
				tabControl1.Enabled = true;
				Application.UseWaitCursor = false;
				lblStatus.Text = "Status: " + this.getGEngineStatus();
			}
			DateTime tme1 = DateTime.Now;
			TimeSpan span = tme1.Subtract(tme0);
			txtOutput.Text += "time: " + span.TotalSeconds.ToString() + "\r\n";
		}

		private void chkMethod_CheckedChanged(object sender, EventArgs e) {
			////enable inputs based on selected methods
			//int methods = this.getMethods();
			//TabPage.ControlCollection ctrls = tabPage1.Controls;
			//for(int i=0;i<ctrls.Count;i++) {
			//	if(ctrls[i].Tag != null) {
			//		ctrls[i].Enabled = ((int)ctrls[i].Tag & methods) > 0;
			//	}
			//}
		}

		private void btnTEGeocode_Click(object sender, EventArgs e) {
			DateTime tme0 = DateTime.Now;
			try {
				txtOutput.Text = "";
				btnGeocode.Enabled = false;
				btnTEGeocode.Enabled = false;
				tabControl1.Enabled = false;
				Application.UseWaitCursor = true;
				Application.DoEvents();
				GeocodeEngine.GeocodeInput Params = this.readInputs();
				GeocodeEngine.GeocodeOutput Results = new GeocodeEngine.GeocodeOutput(Params);
				string url = "";
				if (this.webMode || this.webMode2) {
					url = Settings1.Default.SOE_TE + "Geocode2?f=pjson";
					url += paramsToQuery2(Params);
					//url += "&TownCode=" + Params.TownCode;
					//url += "&AtInt_Road1=" + (Params.AI_RoadName1 ?? "");
					//url += "&AtInt_RouteNum1=" + (Params.AI_RouteNum1 ?? "");
					//url += "&AtInt_RouteDir1=" + (Params.AI_RouteDir1 ?? "");
					//url += "&AtInt_Road2=" + (Params.AI_RoadName2 ?? "");
					//url += "&AtInt_RouteNum2=" + (Params.AI_RouteNum2 ?? "");
					//url += "&AtInt_RouteDir2=" + (Params.AI_RouteDir2 ?? "");
					//url += "&AtInt_Road3=" + (Params.AI_RoadName3 ?? "");
					//url += "&AtInt_RoueNum3=" + (Params.AI_RouteNum3 ?? "");
					//url += "&AtInt_RouteDir3=" + (Params.AI_RouteDir3 ?? "");
					//url += "&OffInt_Road1=" + (Params.OI_RoadName1 ?? "");
					//url += "&OffInt_RouteNum1=" + (Params.OI_RouteNum1 ?? "");
					//url += "&OffInt_RouteDir1=" + (Params.OI_RouteDir1 ?? "");
					//url += "&OffInt_Road2=" + (Params.OI_RoadName2 ?? "");
					//url += "&OffInt_RouteNum2=" + (Params.OI_RouteNum2 ?? "");
					//url += "&OffInt_RouteDir2=" + (Params.OI_RouteDir2 ?? "");
					//url += "&OffInt_OffsetDir=" + (Params.OI_Dir ?? "");
					//url += "&OffInt_OffsetDist=" + (Params.OI_Dist != null ? Params.OI_Dist.ToString() : "");
					//url += "&Address=" + (Params.OI_AddrNum ?? "");
					//url += "&Exit_RouteNum=" + (Params.EX_RouteNum ?? "");
					//url += "&Exit_RouteDir=" + (Params.EX_RouteDir ?? "");
					//url += "&ExitNum=" + (Params.EX_Exit ?? "");
					//url += "&Exit_OffsetDir=" + (Params.EX_Dir ?? "");
					//url += "&Exit_OffsetDist=" + (Params.EX_Dist != null ? Params.EX_Dist.ToString() : "");
					//url += "&Mile_RouteNum=" + (Params.MM_RouteNum ?? "");
					//url += "&Mile_RouteDir=" + (Params.MM_RouteDir ?? "");
					//url += "&MileMark=" + Params.MM_Mile;
					//url += "&Mile_OffsetDir=" + (Params.MM_Dir ?? "");
					//url += "&Mile_OffsetDist=" + (Params.MM_Dist != null ? Params.MM_Dist.ToString() : "");
					//url += "&Landmark=" + (Params.LM_Landmark ?? "");
					//url += "&Landmark_OffsetDir=" + (Params.LM_Dir ?? "");
					//url += "&Landmark_OffsetDist=" + (Params.LM_Dist != null ? Params.LM_Dist.ToString() : "");
					//url += "&Rotary=" + (Params.RO_Rotary ?? "");
					//url += "&CoordX=" + Params.GPS_X;
					//url += "&CoordY=" + Params.GPS_Y;
					//url += "&token=" + this.token;
					string json = getUrl(url);
					Results = JsonConvert.DeserializeObject<GeocodeEngine.GeocodeOutput>(json);
				} else {    //local mode
					int methods = this.getMethods();
					Results = TE.Geocode(Params, methods);
				}
				this.displayResults(Results);
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			} finally {
				btnGeocode.Enabled = true;
				btnTEGeocode.Enabled = true;
				tabControl1.Enabled = true;
				Application.UseWaitCursor = false;
				lblStatus.Text = "Status: " + this.getGEngineStatus();
			}
			DateTime tme1 = DateTime.Now;
			TimeSpan span = tme1.Subtract(tme0);
			txtOutput.Text += "time: " + span.TotalSeconds.ToString() + "\r\n";
		}

		private void btnClear_Click(object sender, EventArgs e) {
			//cbxAccessCtrl.Text = "";
			//cbxAIRouteDir1.Text = "";
			//cbxAIRouteDir2.Text = "";
			//cbxAIRouteDir3.Text = "";
			//cbxControlFunc.Text = "";
			//cbxControlType.Text = "";
			//cbxEXDir.Text = "";
			//cbxEXRouteDir.Text = "";
			//cbxFacilityType.Text = "";
			//cbxJuntionType.Text = "";
			//cbxLMDir.Text = "";
			//cbxMMDir.Text = "";
			//cbxMMRouteDir.Text = "";
			cbxOIDir.Text = "";
			//cbxOIRouteDir1.Text = "";
			//cbxOIRouteDir2.Text = "";
			//cbxPoliceDept.Text = "";
			cbxTown.Text = "";
			//txtADRoadName.Text = "";
			txtAIRoadName1.Text = "";
			txtAIRoadName2.Text = "";
			//txtAIRoadName3.Text = "";
			//txtAIRouteNum1.Text = "";
			//txtAIRouteNum2.Text = "";
			//txtAIRouteNum3.Text = "";
			txtCrashNum.Text = "";
			//txtEXDist.Text = "";
			txtEXExit.Text = "";
			//txtEXRouteNum.Text = "";
			txtGPSX.Text = "";
			txtGPSY.Text = "";
			//txtLMDist.Text = "";
			txtLMLandmark.Text = "";
			//txtMMDist.Text = "";
			txtMMMile.Text = "";
			//txtMMRouteNum.Text = "";
			txtOIAddrNum.Text = "";
			txtOIDist.Text = "";
			//txtOIRoadName1.Text = "";
			//txtOIRoadName2.Text = "";
			//txtOIRouteNum1.Text = "";
			//txtOIRouteNum2.Text = "";
			txtRevX.Text = "";
			txtRevY.Text = "";
			//txtSpeedLimit.Text = "";
			txtRMRefMark.Text = "";
			txtOutput.Text = "Inputs Cleared";
		}

		////////////////////////////////////////////////////////////
		// reverse tab

		private void btnRevGeocode_Click(object sender, EventArgs e) {
			DateTime tme0 = DateTime.Now;
			try {
				txtOutput.Text = "";
				tabControl1.Enabled = false;
				btnRevGeocode.Enabled = false;
				Application.UseWaitCursor = true;
				Application.DoEvents();
				GeocodeEngine.GeocodeInput Results = new GeocodeEngine.GeocodeInput();
				GeocodeEngine.GeocodeCandidate C = new GeocodeEngine.GeocodeCandidate();

				//get inputs
				double x, y;
				if (double.TryParse(txtRevX.Text, out x) && double.TryParse(txtRevY.Text, out y)) {
					string url = "";
					if (this.webMode || this.webMode2) {
						url = Settings1.Default.SOE_GE + "ReverseGeocode?f=pjson";
						url += "&x=" + x.ToString();
						url += "&y=" + y.ToString();
						url += "&token=" + this.token;
						string json = getUrl(url);
						Results = JsonConvert.DeserializeObject<GeocodeEngine.GeocodeInput>(json);
					} else {    //local mode
						Results = GE.ReverseGeocode(x, y, "", C);
					}
					//display output
					txtOutput.Text = "";
					txtOutput.Text += JsonConvert.SerializeObject(Results, Formatting.Indented) + "\r\n\r\n";
					if (C != null) txtOutput.Text += JsonConvert.SerializeObject(C, Formatting.Indented) + "\r\n\r\n";
				} else {
					MessageBox.Show("Invalid inputs");
				}
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			} finally {
				btnRevGeocode.Enabled = true;
				tabControl1.Enabled = true;
				Application.UseWaitCursor = false;
				//lblStatus.Text = "Status: " + this.getGEngineStatus();
			}
			DateTime tme1 = DateTime.Now;
			TimeSpan span = tme1.Subtract(tme0);
			txtOutput.Text += "time: " + span.TotalSeconds.ToString() + "\r\n";
		}

		////////////////////////////////////////////////////////////
		// transaction tab

		private void btnTELoadCrashNum_Click(object sender, EventArgs e) {
			DateTime tme0 = DateTime.Now;
			try {
				txtOutput.Text = "";
				tabControl1.Enabled = false;
				btnTELoadCrashNum.Enabled = false;
				btnTEGeocodeCrashId.Enabled = false;
				Application.UseWaitCursor = true;
				Application.DoEvents();
				string crashnum = (txtCrashNum.Text);
				GeocodeEngine.GeocodeInput rpt;
				if (this.webMode || this.webMode2) {
					string url = "";
					url = Settings1.Default.SOE_TE + "LoadCrashNum?f=pjson";
					url += "&CrashNum=" + crashnum.ToString();
					url += "&token=" + this.token;
					string json = getUrl(url);
					rpt = JsonConvert.DeserializeObject<GeocodeEngine.GeocodeInput>(json);
				} else {
					if (this.TE == null) this.TE = new GeocodeEngine.TEngine(this.dbConnStrCfg);
					rpt = this.TE.loadCrashNumb(crashnum);
				}
				int i;
				for(i=0;i<cbxCounty.Items.Count;i++) {

				}
				for (i = 0; i < cbxTown.Items.Count; i++) {
					if (cbxTown.Items[i].ToString().IndexOf(rpt.TownFIPS + ":") == 0) cbxTown.SelectedIndex = i;
				}
				txtAIRoadName1.Text = rpt.AI_RoadName1 ?? "";
				//txtAIRouteNum1.Text = rpt.AI_RouteNum1 ?? "";
				//cbxAIRouteDir1.SelectedIndex = cbxAIRouteDir1.FindStringExact(rpt.AI_RouteDir1);
				txtAIRoadName2.Text = rpt.AI_RoadName2 ?? "";
				//txtAIRouteNum2.Text = rpt.AI_RouteNum2 ?? "";
				//cbxAIRouteDir2.SelectedIndex = cbxAIRouteDir2.FindStringExact(rpt.AI_RouteDir2);
				//txtAIRoadName3.Text = rpt.AI_RoadName3 ?? "";
				//txtAIRouteNum3.Text = rpt.AI_RouteNum3 ?? "";
				//cbxAIRouteDir3.SelectedIndex = cbxAIRouteDir3.FindStringExact(rpt.AI_RouteDir3);
				//txtOIRoadName1.Text = rpt.OI_RoadName1 ?? "";
				//txtOIRouteNum1.Text = rpt.OI_RouteNum1 ?? "";
				//cbxOIRouteDir1.SelectedIndex = cbxOIRouteDir1.FindStringExact(rpt.OI_RouteDir1);
				//txtOIRoadName2.Text = rpt.OI_RoadName2 ?? "";
				//txtOIRouteNum2.Text = rpt.OI_RouteNum2 ?? "";
				//cbxOIRouteDir2.SelectedIndex = cbxOIRouteDir2.FindStringExact(rpt.OI_RouteDir2);
				//txtADRoadName.Text = rpt.OI_RoadName1 ?? "";
				//chkAtInt.Checked = rpt.AtInt;
				txtOIAddrNum.Text = rpt.OI_AddrNum ?? "";
				txtOIDist.Text = (rpt.Offset_Dist ?? 0).ToString();
				cbxOIDir.SelectedIndex = cbxOIDir.FindStringExact(rpt.Offset_Dir);
				//txtMMRouteNum.Text = rpt.MM_RouteNum ?? "";
				//cbxMMRouteDir.SelectedIndex = cbxMMRouteDir.FindStringExact(rpt.MM_RouteDir);
				txtMMMile.Text = (rpt.MM_Mile == null ? "" : rpt.MM_Mile.ToString());
				//txtMMDist.Text = (rpt.MM_Dist ?? 0).ToString();
				//cbxMMDir.SelectedIndex = cbxMMDir.FindStringExact(rpt.MM_Dir);
				//txtEXRouteNum.Text = rpt.EX_RouteNum ?? "";
				//cbxEXRouteDir.SelectedIndex = cbxEXRouteDir.FindStringExact(rpt.EX_RouteDir);
				txtEXExit.Text = rpt.EX_Exit ?? "";
				txtRMRefMark.Text = rpt.RM_RefMark ?? "";
				//txtEXDist.Text = (rpt.EX_Dist ?? 0).ToString();
				//cbxEXDir.SelectedIndex = cbxEXDir.FindStringExact(rpt.EX_Dir);
				txtLMLandmark.Text = rpt.LM_Landmark ?? "";
				//txtLMDist.Text = (rpt.LM_Dist ?? 0).ToString();
				//cbxLMDir.SelectedIndex = cbxLMDir.FindStringExact(rpt.LM_Dir);
				txtGPSX.Text = (rpt.GPS_X == null ? "" : rpt.GPS_X.ToString());
				txtGPSY.Text = (rpt.GPS_Y == null ? "" : rpt.GPS_Y.ToString());
				//for (i = 0; i < cbxJuntionType.Items.Count; i++) { if ((cbxJuntionType.Items[i] as GeocodeEngine.lutItem).Value == rpt.JunctionType) cbxJuntionType.SelectedIndex = i; }
				//for (i = 0; i < cbxFacilityType.Items.Count; i++) { if ((cbxFacilityType.Items[i] as GeocodeEngine.lutItem).Value == rpt.FacilityType) cbxFacilityType.SelectedIndex = i; }
				//for (i = 0; i < cbxControlType.Items.Count; i++) { if ((cbxControlType.Items[i] as GeocodeEngine.lutItem).Value == rpt.ControlType) cbxControlType.SelectedIndex = i; }
				//for (i = 0; i < cbxControlFunc.Items.Count; i++) { if ((cbxControlFunc.Items[i] as GeocodeEngine.lutItem).Value == rpt.ControlFunc) cbxControlFunc.SelectedIndex = i; }
				//for (i = 0; i < cbxAccessCtrl.Items.Count; i++) { if ((cbxAccessCtrl.Items[i] as GeocodeEngine.lutItem).Value == rpt.AccessCtrl) cbxAccessCtrl.SelectedIndex = i; }
				//for (i = 0; i < cbxPoliceDept.Items.Count; i++) { if ((cbxPoliceDept.Items[i] as GeocodeEngine.lutItem).Value == rpt.PoliceDept) cbxPoliceDept.SelectedIndex = i; }
				//txtSpeedLimit.Text = rpt.SpeedLimit;
				//tabControl1.SelectedIndex = 0;
				txtOutput.Text = "Crash " + crashnum.ToString() + " NOT FOUND\r\n";
				if (rpt.CrashNum != "0") txtOutput.Text = "Crash " + crashnum.ToString() + " loaded\r\n";
				lblStatus.Text = "Status: " + getGEngineStatus();

			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			} finally {
				tabControl1.Enabled = true;
				btnTELoadCrashNum.Enabled = true;
				btnTEGeocodeCrashId.Enabled = true;
				Application.UseWaitCursor = false;
			}
			DateTime tme1 = DateTime.Now;
			TimeSpan span = tme1.Subtract(tme0);
			txtOutput.Text += "time: " + span.TotalSeconds.ToString() + "\r\n";
		}

		private void btnTEGeocodeCrashId_Click(object sender, EventArgs e) {
			bool testing = chkTesting.Checked;
			DateTime tme0 = DateTime.Now;
			//batch process
			try {
				//btnTELoadCrashNum_Click(sender, e);
				txtOutput.Text = "";
				tabControl1.Enabled = false;
				btnTELoadCrashNum.Enabled = false;
				btnTEGeocodeCrashId.Enabled = false;
				Application.UseWaitCursor = true;
				Application.DoEvents();
				string crashnum = (txtCrashNum.Text);
				//GeocodeEngine.GeocodeInput rpt;
				if (this.webMode || this.webMode2) {
					string url = "";
					url = Settings1.Default.SOE_TE + "GeocodeCrashNum?f=pjson";
					url += "&CrashNum=" + crashnum.ToString();
					if (testing) url += "&Test=1";
					url += "&token=" + this.token;
					string json = getUrl(url);
					GeocodeEngine.GeocodeOutput GO = JsonConvert.DeserializeObject<GeocodeEngine.GeocodeOutput>(json);
					this.displayResults(GO);
				} else {
					if (this.TE == null) this.TE = new GeocodeEngine.TEngine(this.dbConnStrCfg);
					GeocodeEngine.GeocodeOutput GO = this.TE.GeocodeCrash(crashnum, testing);
					//this.displayResults(GO);
					txtOutput.Text += JsonConvert.SerializeObject(GO) + "\r\n";
				}
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			} finally {
				tabControl1.Enabled = true;
				btnTELoadCrashNum.Enabled = true;
				btnTEGeocodeCrashId.Enabled = true;
				Application.UseWaitCursor = false;
			}
			DateTime tme1 = DateTime.Now;
			TimeSpan span = tme1.Subtract(tme0);
			txtOutput.Text += "time: " + span.TotalSeconds.ToString() + "\r\n";
		}

		private void btnCommonAttrs_Click(object sender, EventArgs e) {
			bool testing = chkTesting.Checked;
			DateTime tme0 = DateTime.Now;
			txtOutput.Text = "";
			try {
				string crashnum = (txtCrashNum.Text);
				if (this.TE == null) this.TE = new GeocodeEngine.TEngine(this.dbConnStrCfg);
				Dictionary<string, string> dict = TE.SaveCommonRoadAttrs(crashnum, "", "", "", testing);
				foreach (KeyValuePair<string, string> entry in dict) {
					if (entry.Value != null) {
						txtOutput.Text += entry.Key + " = " + entry.Value + "\r\n";
					} else {
						txtOutput.Text += entry.Key + " = null \r\n";
					}
				}
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			}
			DateTime tme1 = DateTime.Now;
			TimeSpan span = tme1.Subtract(tme0);
			txtOutput.Text += "time: " + span.TotalSeconds.ToString() + "\r\n";
		}

		private void btnSaveCandRoadAttr_Click(object sender, EventArgs e) {
			bool testing = chkTesting.Checked;
			DateTime tme0 = DateTime.Now;
			txtOutput.Text = "";
			try {
				string crashnum = (txtCrashNum.Text);
				//int candid = int.Parse(txtCandID.Text);
				if (this.TE == null) this.TE = new GeocodeEngine.TEngine(this.dbConnStrCfg);
				Dictionary<string, string> dict = TE.SaveCandidateRoadAttrs(crashnum, testing);
				foreach (KeyValuePair<string, string> entry in dict) {
					if (entry.Value != null) {
						txtOutput.Text += entry.Key + " = " + entry.Value + "\r\n";
					} else {
						txtOutput.Text += entry.Key + " = null \r\n";
					}
				}
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			}
			DateTime tme1 = DateTime.Now;
			TimeSpan span = tme1.Subtract(tme0);
			txtOutput.Text += "time: " + span.TotalSeconds.ToString() + "\r\n";
		}

		////////////////////////////////////////////////////////////
		// admin tab 

		private void cbxCfgGrp_SelectedIndexChanged(object sender, EventArgs e) {
			try {
				if (this.webMode || this.webMode2) {
					string json = getUrl(Settings1.Default.SOE_TE + "ReadSettings?f=json&Password=agis2447agis2447&token=" + this.token);
					this.Settings = JsonConvert.DeserializeObject<List<GeocodeEngine.settingItem>>(json);
				} else {
					this.Settings = this.TE.readSettings();
				}
				dgvSettings.Rows.Clear();
				string grp = (cbxCfgGrp.SelectedItem ?? "").ToString();
				foreach (GeocodeEngine.settingItem item in this.Settings) {
					//if (item.Name == "dbConnApp" || item.Name == "dbConnGDB" || item.Name == "dbConnSDE" || item.Name == "SourceDB" || item.Name == "TargetDB") item.Value = GeocodeEngine.Config.Decrypt(item.Value);
					if (item.Grp == grp) {
						DataGridViewRow row = new DataGridViewRow();
						row.CreateCells(dgvSettings);
						row.Cells[0].Value = item.Name;
						row.Cells[1].Value = item.Value;
						dgvSettings.Rows.Add(row);
					}
				}
				//write settings to grid
				//string sql = "select Name, Value from Settings where Grp='" + grp + "' order by Name";
				//if (externalMode) {  //for delivery, remove connection settings
				//	sql = "select Name, Value from Settings where Grp='" + grp + "' and Name not like 'dbConn%' order by Name";
				//}
				//updateGrid(dgvSettings, sql);
				dgvSettings.ReadOnly = false;
				dgvSettings.AutoResizeColumns();
				dgvSettings.ClearSelection();
				dgvSettings.Focus();
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			}
		}
		/*
		private void updateGrid(DataGridView dgv, string sql) {
			using (SqlConnection dbConn = new SqlConnection(this.dbConnStrCfg)) {
				////get current selection
				//DataGridViewCell dgvCell;
				//string rowId = "-1";
				//try {
				//	if (dgv.SelectedCells.Count > 0) {
				//		dgvCell = dgv.SelectedCells[0].OwningRow.Cells[0];
				//		rowId = dgvCell.Value.ToString();
				//	}
				//} catch (Exception) {; }
				// fill a DataGridView from a query
				SqlCommand dbCmd = new SqlCommand(sql, dbConn);
				SqlDataAdapter dbAdapter = new SqlDataAdapter(dbCmd);
				SqlCommandBuilder dbCmdBldr = new SqlCommandBuilder(dbAdapter);
				DataSet dbDS = new DataSet();
				dbAdapter.Fill(dbDS, "Query");
				dgv.DataSource = dbDS.Tables["Query"];
				dgv.ReadOnly = false;
				dgv.AutoResizeColumns();
				dgv.ClearSelection();
				////restore selection
				//if (rowId != "-1") {
				//	for (int i = 0; i < dgv.RowCount - 1; i++) {
				//		if (dgv.Rows[i].Cells[0].Value.ToString() == rowId) {
				//			dgv.CurrentCell = dgv.Rows[i].Cells[0];
				//		}
				//	}
				//}
			}
		}
		*/
		private void btnReload_Click(object sender, EventArgs e) {
			cbxCfgGrp_SelectedIndexChanged(null, null);
		}

		private void btnSave_Click(object sender, EventArgs e) {
			try {
				string connString = this.dbConnStrCfg;
				string grp = cbxCfgGrp.SelectedItem.ToString();
				string name, value;
				txtOutput.Text = "";
				DataGridViewRowCollection rows = dgvSettings.Rows;
				if (this.webMode || this.webMode2) {
					string url = "";
					for (int i = 0; i < rows.Count; i++) {
						name = rows[i].Cells[0].Value.ToString();
						value = rows[i].Cells[1].Value.ToString();
						if (name == "dbConnApp") connString = value;
						url = Settings1.Default.SOE_TE + "SaveSetting?f=json&Password=agis2447agis2447&Group=" + grp + "&Name=" + name + "&Value=" + value;
						url += "&token=" + this.token;
						getUrl(url);
					}
				} else {
					for (int i = 0; i < rows.Count; i++) {
						name = rows[i].Cells[0].Value.ToString();
						value = rows[i].Cells[1].Value.ToString();
						if (name == "dbConnApp") connString = value;
						this.TE.saveSetting(grp, name, value);
					}
					GeocodeEngine.Config.load(connString);  //re-configure engine
				}
				this.txtOutput.Text += "Settings Saved\r\n";
				lblStatus.Text = "Status: " + getGEngineStatus();
				cbxCfgGrp_SelectedIndexChanged(null, null); //reload settings
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			}
		}

		private void btnReset_Click(object sender, EventArgs e) {
			try {
				if (this.webMode || this.webMode2) {
					var url = Settings1.Default.SOE_TE + "ResetSettings?f=json";
					url += "&token=" + this.token;
					getUrl(url);
				} else {
					this.TE.resetSettings();
				}
				cbxCfgGrp_SelectedIndexChanged(null, null);
				txtOutput.Text = "Settings Reset";
			} catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			}
		}

		////////////////////////////////////////////////////////////////////
		private void btnTest_Click(object sender, EventArgs e) {
			string x = "11-urban princ art interstate";
			int y = int.Parse(x);
			txtOutput.Text = y.ToString();
			//GeocodeEngine.Logger.err("test error message");
		}

		private void cbx_Enter(object sender, EventArgs e) {
			(sender as ComboBox).SelectAll();
		}
		private void txt_Enter(object sender, EventArgs e) {
			(sender as TextBox).SelectAll();
		}

		private void btnAItest_Click(object sender, EventArgs e) {
			IDictionary<string, string> state = new Dictionary<string, string>();
			state.Add("item 1", "value 1");
			state.Add("item 2", "value 2");
			//aiClient.TrackEvent("Geocode Test Client", state);
		}

		private void btnEncrypt_Click(object sender, EventArgs e) {
			string txt1 = txtClear.Text;
			string txt2 = GeocodeEngine.Config.Encrypt(txt1);
			txtCrypt.Text = txt2;
		}

		private void btnDecrypt_Click(object sender, EventArgs e) {
			string txt1 = txtCrypt.Text;
			string txt2 = GeocodeEngine.Config.Decrypt(txt1);
			txtClear.Text = txt2;
		}
	}
}
