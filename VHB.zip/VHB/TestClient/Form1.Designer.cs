﻿namespace TestClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.label8 = new System.Windows.Forms.Label();
			this.cbxCounty = new System.Windows.Forms.ComboBox();
			this.txtZIP = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnTEGeocode = new System.Windows.Forms.Button();
			this.lblStatus = new System.Windows.Forms.Label();
			this.btnTest = new System.Windows.Forms.Button();
			this.label58 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.chkMethodCoords = new System.Windows.Forms.CheckBox();
			this.chkMethodRM = new System.Windows.Forms.CheckBox();
			this.chkMethodLmrk = new System.Windows.Forms.CheckBox();
			this.chkMethodMile = new System.Windows.Forms.CheckBox();
			this.chkMethodExit = new System.Windows.Forms.CheckBox();
			this.chkMethodAddr = new System.Windows.Forms.CheckBox();
			this.chkMethodOffInt = new System.Windows.Forms.CheckBox();
			this.chkMethodAtInt = new System.Windows.Forms.CheckBox();
			this.btnGeocode = new System.Windows.Forms.Button();
			this.tabControl2 = new System.Windows.Forms.TabControl();
			this.tabNY = new System.Windows.Forms.TabPage();
			this.label3 = new System.Windows.Forms.Label();
			this.txtOIRoadName2 = new System.Windows.Forms.TextBox();
			this.label60 = new System.Windows.Forms.Label();
			this.label59 = new System.Windows.Forms.Label();
			this.txtGPSY = new System.Windows.Forms.TextBox();
			this.txtGPSX = new System.Windows.Forms.TextBox();
			this.chkParking = new System.Windows.Forms.CheckBox();
			this.txtRMRefMark = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label48 = new System.Windows.Forms.Label();
			this.txtMMMile = new System.Windows.Forms.TextBox();
			this.label56 = new System.Windows.Forms.Label();
			this.txtLMLandmark = new System.Windows.Forms.TextBox();
			this.label51 = new System.Windows.Forms.Label();
			this.txtEXExit = new System.Windows.Forms.TextBox();
			this.cbxOffOpt = new System.Windows.Forms.ComboBox();
			this.cbxOffUnit = new System.Windows.Forms.ComboBox();
			this.label35 = new System.Windows.Forms.Label();
			this.cbxOIDir = new System.Windows.Forms.ComboBox();
			this.txtOIDist = new System.Windows.Forms.TextBox();
			this.label27 = new System.Windows.Forms.Label();
			this.txtAIRoadName2 = new System.Windows.Forms.TextBox();
			this.chkAtInt = new System.Windows.Forms.CheckBox();
			this.label26 = new System.Windows.Forms.Label();
			this.txtAIRoadName1 = new System.Windows.Forms.TextBox();
			this.label34 = new System.Windows.Forms.Label();
			this.txtOIAddrNum = new System.Windows.Forms.TextBox();
			this.cbxTown = new System.Windows.Forms.ComboBox();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btnRevGeocode = new System.Windows.Forms.Button();
			this.txtRevY = new System.Windows.Forms.TextBox();
			this.txtRevX = new System.Windows.Forms.TextBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.chkTesting = new System.Windows.Forms.CheckBox();
			this.btnSaveCandRoadAttr = new System.Windows.Forms.Button();
			this.btnCommonAttrs = new System.Windows.Forms.Button();
			this.btnTEGeocodeCrashId = new System.Windows.Forms.Button();
			this.btnTELoadCrashNum = new System.Windows.Forms.Button();
			this.label22 = new System.Windows.Forms.Label();
			this.txtCrashNum = new System.Windows.Forms.TextBox();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.btnDecrypt = new System.Windows.Forms.Button();
			this.btnEncrypt = new System.Windows.Forms.Button();
			this.txtCrypt = new System.Windows.Forms.TextBox();
			this.txtClear = new System.Windows.Forms.TextBox();
			this.btnAItest = new System.Windows.Forms.Button();
			this.btnReset = new System.Windows.Forms.Button();
			this.label21 = new System.Windows.Forms.Label();
			this.btnReload = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.dgvSettings = new System.Windows.Forms.DataGridView();
			this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.cbxCfgGrp = new System.Windows.Forms.ComboBox();
			this.txtOutput = new System.Windows.Forms.TextBox();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.txtCrashDate = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.tabControl1.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.tabControl2.SuspendLayout();
			this.tabNY.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvSettings)).BeginInit();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Location = new System.Drawing.Point(13, 13);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(505, 416);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage4
			// 
			this.tabPage4.Controls.Add(this.label6);
			this.tabPage4.Controls.Add(this.txtCrashDate);
			this.tabPage4.Controls.Add(this.label8);
			this.tabPage4.Controls.Add(this.cbxCounty);
			this.tabPage4.Controls.Add(this.txtZIP);
			this.tabPage4.Controls.Add(this.label5);
			this.tabPage4.Controls.Add(this.btnClear);
			this.tabPage4.Controls.Add(this.btnTEGeocode);
			this.tabPage4.Controls.Add(this.lblStatus);
			this.tabPage4.Controls.Add(this.btnTest);
			this.tabPage4.Controls.Add(this.label58);
			this.tabPage4.Controls.Add(this.label19);
			this.tabPage4.Controls.Add(this.chkMethodCoords);
			this.tabPage4.Controls.Add(this.chkMethodRM);
			this.tabPage4.Controls.Add(this.chkMethodLmrk);
			this.tabPage4.Controls.Add(this.chkMethodMile);
			this.tabPage4.Controls.Add(this.chkMethodExit);
			this.tabPage4.Controls.Add(this.chkMethodAddr);
			this.tabPage4.Controls.Add(this.chkMethodOffInt);
			this.tabPage4.Controls.Add(this.chkMethodAtInt);
			this.tabPage4.Controls.Add(this.btnGeocode);
			this.tabPage4.Controls.Add(this.tabControl2);
			this.tabPage4.Controls.Add(this.cbxTown);
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Size = new System.Drawing.Size(497, 390);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Geocode";
			this.tabPage4.UseVisualStyleBackColor = true;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(5, 6);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(40, 13);
			this.label8.TabIndex = 67;
			this.label8.Text = "County";
			// 
			// cbxCounty
			// 
			this.cbxCounty.FormattingEnabled = true;
			this.cbxCounty.Location = new System.Drawing.Point(51, 3);
			this.cbxCounty.Name = "cbxCounty";
			this.cbxCounty.Size = new System.Drawing.Size(58, 21);
			this.cbxCounty.TabIndex = 66;
			// 
			// txtZIP
			// 
			this.txtZIP.Location = new System.Drawing.Point(366, 4);
			this.txtZIP.Name = "txtZIP";
			this.txtZIP.Size = new System.Drawing.Size(21, 20);
			this.txtZIP.TabIndex = 2;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(336, 6);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(24, 13);
			this.label5.TabIndex = 65;
			this.label5.Text = "ZIP";
			// 
			// btnClear
			// 
			this.btnClear.Location = new System.Drawing.Point(383, 304);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(97, 23);
			this.btnClear.TabIndex = 55;
			this.btnClear.Text = "Clear Inputs";
			this.btnClear.UseVisualStyleBackColor = true;
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btnTEGeocode
			// 
			this.btnTEGeocode.Location = new System.Drawing.Point(383, 275);
			this.btnTEGeocode.Name = "btnTEGeocode";
			this.btnTEGeocode.Size = new System.Drawing.Size(97, 23);
			this.btnTEGeocode.TabIndex = 54;
			this.btnTEGeocode.Text = "TE Geocode";
			this.btnTEGeocode.UseVisualStyleBackColor = true;
			this.btnTEGeocode.Click += new System.EventHandler(this.btnTEGeocode_Click);
			// 
			// lblStatus
			// 
			this.lblStatus.AutoSize = true;
			this.lblStatus.Location = new System.Drawing.Point(49, 370);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(43, 13);
			this.lblStatus.TabIndex = 2;
			this.lblStatus.Text = "Status: ";
			// 
			// btnTest
			// 
			this.btnTest.Location = new System.Drawing.Point(404, 360);
			this.btnTest.Name = "btnTest";
			this.btnTest.Size = new System.Drawing.Size(75, 23);
			this.btnTest.TabIndex = 56;
			this.btnTest.Text = "Test";
			this.btnTest.UseVisualStyleBackColor = true;
			this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
			// 
			// label58
			// 
			this.label58.AutoSize = true;
			this.label58.Location = new System.Drawing.Point(115, 6);
			this.label58.Name = "label58";
			this.label58.Size = new System.Drawing.Size(30, 13);
			this.label58.TabIndex = 64;
			this.label58.Text = "Muni";
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label19.Location = new System.Drawing.Point(380, 31);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(48, 13);
			this.label19.TabIndex = 55;
			this.label19.Text = "Methods";
			// 
			// chkMethodCoords
			// 
			this.chkMethodCoords.AutoSize = true;
			this.chkMethodCoords.Checked = true;
			this.chkMethodCoords.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodCoords.Location = new System.Drawing.Point(383, 196);
			this.chkMethodCoords.Name = "chkMethodCoords";
			this.chkMethodCoords.Size = new System.Drawing.Size(48, 17);
			this.chkMethodCoords.TabIndex = 51;
			this.chkMethodCoords.Text = "GPS";
			this.toolTip1.SetToolTip(this.chkMethodCoords, "method 10");
			this.chkMethodCoords.UseVisualStyleBackColor = true;
			// 
			// chkMethodRM
			// 
			this.chkMethodRM.AutoSize = true;
			this.chkMethodRM.Checked = true;
			this.chkMethodRM.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodRM.Location = new System.Drawing.Point(383, 220);
			this.chkMethodRM.Name = "chkMethodRM";
			this.chkMethodRM.Size = new System.Drawing.Size(79, 17);
			this.chkMethodRM.TabIndex = 52;
			this.chkMethodRM.Text = "Ref Marker";
			this.toolTip1.SetToolTip(this.chkMethodRM, "method 9");
			this.chkMethodRM.UseVisualStyleBackColor = true;
			// 
			// chkMethodLmrk
			// 
			this.chkMethodLmrk.AutoSize = true;
			this.chkMethodLmrk.Checked = true;
			this.chkMethodLmrk.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodLmrk.Location = new System.Drawing.Point(383, 172);
			this.chkMethodLmrk.Name = "chkMethodLmrk";
			this.chkMethodLmrk.Size = new System.Drawing.Size(73, 17);
			this.chkMethodLmrk.TabIndex = 50;
			this.chkMethodLmrk.Text = "Landmark";
			this.toolTip1.SetToolTip(this.chkMethodLmrk, "method 6");
			this.chkMethodLmrk.UseVisualStyleBackColor = true;
			// 
			// chkMethodMile
			// 
			this.chkMethodMile.AutoSize = true;
			this.chkMethodMile.Checked = true;
			this.chkMethodMile.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodMile.Location = new System.Drawing.Point(383, 148);
			this.chkMethodMile.Name = "chkMethodMile";
			this.chkMethodMile.Size = new System.Drawing.Size(81, 17);
			this.chkMethodMile.TabIndex = 49;
			this.chkMethodMile.Text = "Mile Marker";
			this.toolTip1.SetToolTip(this.chkMethodMile, "method 5");
			this.chkMethodMile.UseVisualStyleBackColor = true;
			// 
			// chkMethodExit
			// 
			this.chkMethodExit.AutoSize = true;
			this.chkMethodExit.Checked = true;
			this.chkMethodExit.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodExit.Location = new System.Drawing.Point(383, 124);
			this.chkMethodExit.Name = "chkMethodExit";
			this.chkMethodExit.Size = new System.Drawing.Size(43, 17);
			this.chkMethodExit.TabIndex = 48;
			this.chkMethodExit.Text = "Exit";
			this.toolTip1.SetToolTip(this.chkMethodExit, "method 4");
			this.chkMethodExit.UseVisualStyleBackColor = true;
			// 
			// chkMethodAddr
			// 
			this.chkMethodAddr.AutoSize = true;
			this.chkMethodAddr.Checked = true;
			this.chkMethodAddr.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodAddr.Location = new System.Drawing.Point(383, 100);
			this.chkMethodAddr.Name = "chkMethodAddr";
			this.chkMethodAddr.Size = new System.Drawing.Size(64, 17);
			this.chkMethodAddr.TabIndex = 47;
			this.chkMethodAddr.Text = "Address";
			this.toolTip1.SetToolTip(this.chkMethodAddr, "method 3");
			this.chkMethodAddr.UseVisualStyleBackColor = true;
			// 
			// chkMethodOffInt
			// 
			this.chkMethodOffInt.AutoSize = true;
			this.chkMethodOffInt.Checked = true;
			this.chkMethodOffInt.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodOffInt.Location = new System.Drawing.Point(383, 76);
			this.chkMethodOffInt.Name = "chkMethodOffInt";
			this.chkMethodOffInt.Size = new System.Drawing.Size(84, 17);
			this.chkMethodOffInt.TabIndex = 46;
			this.chkMethodOffInt.Text = "Off Intersect";
			this.toolTip1.SetToolTip(this.chkMethodOffInt, "method 2");
			this.chkMethodOffInt.UseVisualStyleBackColor = true;
			// 
			// chkMethodAtInt
			// 
			this.chkMethodAtInt.AutoSize = true;
			this.chkMethodAtInt.Checked = true;
			this.chkMethodAtInt.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMethodAtInt.Location = new System.Drawing.Point(383, 52);
			this.chkMethodAtInt.Name = "chkMethodAtInt";
			this.chkMethodAtInt.Size = new System.Drawing.Size(80, 17);
			this.chkMethodAtInt.TabIndex = 45;
			this.chkMethodAtInt.Text = "At Intersect";
			this.toolTip1.SetToolTip(this.chkMethodAtInt, "method 1");
			this.chkMethodAtInt.UseVisualStyleBackColor = true;
			// 
			// btnGeocode
			// 
			this.btnGeocode.Enabled = false;
			this.btnGeocode.Location = new System.Drawing.Point(383, 245);
			this.btnGeocode.Name = "btnGeocode";
			this.btnGeocode.Size = new System.Drawing.Size(97, 23);
			this.btnGeocode.TabIndex = 53;
			this.btnGeocode.Text = "GE Geocode";
			this.btnGeocode.UseVisualStyleBackColor = true;
			this.btnGeocode.Click += new System.EventHandler(this.btnGeocode_Click);
			// 
			// tabControl2
			// 
			this.tabControl2.Controls.Add(this.tabNY);
			this.tabControl2.Location = new System.Drawing.Point(4, 31);
			this.tabControl2.Name = "tabControl2";
			this.tabControl2.SelectedIndex = 0;
			this.tabControl2.Size = new System.Drawing.Size(356, 336);
			this.tabControl2.TabIndex = 2;
			// 
			// tabNY
			// 
			this.tabNY.Controls.Add(this.label3);
			this.tabNY.Controls.Add(this.txtOIRoadName2);
			this.tabNY.Controls.Add(this.label60);
			this.tabNY.Controls.Add(this.label59);
			this.tabNY.Controls.Add(this.txtGPSY);
			this.tabNY.Controls.Add(this.txtGPSX);
			this.tabNY.Controls.Add(this.chkParking);
			this.tabNY.Controls.Add(this.txtRMRefMark);
			this.tabNY.Controls.Add(this.label4);
			this.tabNY.Controls.Add(this.label48);
			this.tabNY.Controls.Add(this.txtMMMile);
			this.tabNY.Controls.Add(this.label56);
			this.tabNY.Controls.Add(this.txtLMLandmark);
			this.tabNY.Controls.Add(this.label51);
			this.tabNY.Controls.Add(this.txtEXExit);
			this.tabNY.Controls.Add(this.cbxOffOpt);
			this.tabNY.Controls.Add(this.cbxOffUnit);
			this.tabNY.Controls.Add(this.label35);
			this.tabNY.Controls.Add(this.cbxOIDir);
			this.tabNY.Controls.Add(this.txtOIDist);
			this.tabNY.Controls.Add(this.label27);
			this.tabNY.Controls.Add(this.txtAIRoadName2);
			this.tabNY.Controls.Add(this.chkAtInt);
			this.tabNY.Controls.Add(this.label26);
			this.tabNY.Controls.Add(this.txtAIRoadName1);
			this.tabNY.Controls.Add(this.label34);
			this.tabNY.Controls.Add(this.txtOIAddrNum);
			this.tabNY.Location = new System.Drawing.Point(4, 22);
			this.tabNY.Name = "tabNY";
			this.tabNY.Size = new System.Drawing.Size(348, 310);
			this.tabNY.TabIndex = 8;
			this.tabNY.Text = "NY";
			this.tabNY.UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(105, 85);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(64, 13);
			this.label3.TabIndex = 64;
			this.label3.Text = "Cross Street";
			// 
			// txtOIRoadName2
			// 
			this.txtOIRoadName2.Location = new System.Drawing.Point(175, 78);
			this.txtOIRoadName2.Name = "txtOIRoadName2";
			this.txtOIRoadName2.Size = new System.Drawing.Size(100, 20);
			this.txtOIRoadName2.TabIndex = 63;
			// 
			// label60
			// 
			this.label60.AutoSize = true;
			this.label60.Location = new System.Drawing.Point(129, 262);
			this.label60.Name = "label60";
			this.label60.Size = new System.Drawing.Size(40, 13);
			this.label60.TabIndex = 60;
			this.label60.Text = "Y / Lat";
			// 
			// label59
			// 
			this.label59.AutoSize = true;
			this.label59.Location = new System.Drawing.Point(126, 233);
			this.label59.Name = "label59";
			this.label59.Size = new System.Drawing.Size(43, 13);
			this.label59.TabIndex = 59;
			this.label59.Text = "X / Lon";
			// 
			// txtGPSY
			// 
			this.txtGPSY.Location = new System.Drawing.Point(175, 259);
			this.txtGPSY.Name = "txtGPSY";
			this.txtGPSY.Size = new System.Drawing.Size(100, 20);
			this.txtGPSY.TabIndex = 62;
			this.toolTip1.SetToolTip(this.txtGPSY, "Y / Latitude");
			// 
			// txtGPSX
			// 
			this.txtGPSX.Location = new System.Drawing.Point(175, 232);
			this.txtGPSX.Name = "txtGPSX";
			this.txtGPSX.Size = new System.Drawing.Size(100, 20);
			this.txtGPSX.TabIndex = 61;
			this.toolTip1.SetToolTip(this.txtGPSX, "X / Longitude");
			// 
			// chkParking
			// 
			this.chkParking.AutoSize = true;
			this.chkParking.Location = new System.Drawing.Point(175, 208);
			this.chkParking.Name = "chkParking";
			this.chkParking.Size = new System.Drawing.Size(77, 17);
			this.chkParking.TabIndex = 58;
			this.chkParking.Text = "Non-public";
			this.chkParking.UseVisualStyleBackColor = true;
			// 
			// txtRMRefMark
			// 
			this.txtRMRefMark.Location = new System.Drawing.Point(175, 182);
			this.txtRMRefMark.Name = "txtRMRefMark";
			this.txtRMRefMark.Size = new System.Drawing.Size(100, 20);
			this.txtRMRefMark.TabIndex = 57;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(76, 189);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(93, 13);
			this.label4.TabIndex = 56;
			this.label4.Text = "Reference Marker";
			// 
			// label48
			// 
			this.label48.AutoSize = true;
			this.label48.Location = new System.Drawing.Point(120, 159);
			this.label48.Name = "label48";
			this.label48.Size = new System.Drawing.Size(49, 13);
			this.label48.TabIndex = 55;
			this.label48.Text = "Milemark";
			// 
			// txtMMMile
			// 
			this.txtMMMile.Location = new System.Drawing.Point(175, 156);
			this.txtMMMile.Name = "txtMMMile";
			this.txtMMMile.Size = new System.Drawing.Size(100, 20);
			this.txtMMMile.TabIndex = 54;
			this.toolTip1.SetToolTip(this.txtMMMile, "Mile Marker");
			// 
			// label56
			// 
			this.label56.AutoSize = true;
			this.label56.Location = new System.Drawing.Point(115, 133);
			this.label56.Name = "label56";
			this.label56.Size = new System.Drawing.Size(54, 13);
			this.label56.TabIndex = 53;
			this.label56.Text = "Landmark";
			// 
			// txtLMLandmark
			// 
			this.txtLMLandmark.Location = new System.Drawing.Point(175, 130);
			this.txtLMLandmark.Name = "txtLMLandmark";
			this.txtLMLandmark.Size = new System.Drawing.Size(100, 20);
			this.txtLMLandmark.TabIndex = 52;
			this.toolTip1.SetToolTip(this.txtLMLandmark, "Landmark Name");
			// 
			// label51
			// 
			this.label51.AutoSize = true;
			this.label51.Location = new System.Drawing.Point(144, 107);
			this.label51.Name = "label51";
			this.label51.Size = new System.Drawing.Size(24, 13);
			this.label51.TabIndex = 51;
			this.label51.Text = "Exit";
			// 
			// txtEXExit
			// 
			this.txtEXExit.Location = new System.Drawing.Point(175, 104);
			this.txtEXExit.Name = "txtEXExit";
			this.txtEXExit.Size = new System.Drawing.Size(100, 20);
			this.txtEXExit.TabIndex = 50;
			this.toolTip1.SetToolTip(this.txtEXExit, "Exit Number");
			// 
			// cbxOffOpt
			// 
			this.cbxOffOpt.FormattingEnabled = true;
			this.cbxOffOpt.Location = new System.Drawing.Point(220, 49);
			this.cbxOffOpt.Name = "cbxOffOpt";
			this.cbxOffOpt.Size = new System.Drawing.Size(121, 21);
			this.cbxOffOpt.TabIndex = 49;
			// 
			// cbxOffUnit
			// 
			this.cbxOffUnit.FormattingEnabled = true;
			this.cbxOffUnit.Location = new System.Drawing.Point(150, 50);
			this.cbxOffUnit.Name = "cbxOffUnit";
			this.cbxOffUnit.Size = new System.Drawing.Size(63, 21);
			this.cbxOffUnit.TabIndex = 48;
			// 
			// label35
			// 
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(3, 57);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(35, 13);
			this.label35.TabIndex = 47;
			this.label35.Text = "Offset";
			// 
			// cbxOIDir
			// 
			this.cbxOIDir.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			this.cbxOIDir.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			this.cbxOIDir.FormattingEnabled = true;
			this.cbxOIDir.Location = new System.Drawing.Point(91, 50);
			this.cbxOIDir.Name = "cbxOIDir";
			this.cbxOIDir.Size = new System.Drawing.Size(53, 21);
			this.cbxOIDir.TabIndex = 46;
			this.toolTip1.SetToolTip(this.cbxOIDir, "Offset Dir");
			// 
			// txtOIDist
			// 
			this.txtOIDist.Location = new System.Drawing.Point(44, 50);
			this.txtOIDist.Name = "txtOIDist";
			this.txtOIDist.Size = new System.Drawing.Size(40, 20);
			this.txtOIDist.TabIndex = 45;
			this.txtOIDist.Text = "0";
			this.toolTip1.SetToolTip(this.txtOIDist, "Offset Dist");
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(172, 33);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(42, 13);
			this.label27.TabIndex = 44;
			this.label27.Text = "Road 2";
			// 
			// txtAIRoadName2
			// 
			this.txtAIRoadName2.Location = new System.Drawing.Point(220, 29);
			this.txtAIRoadName2.Name = "txtAIRoadName2";
			this.txtAIRoadName2.Size = new System.Drawing.Size(100, 20);
			this.txtAIRoadName2.TabIndex = 43;
			this.toolTip1.SetToolTip(this.txtAIRoadName2, "Road Name");
			// 
			// chkAtInt
			// 
			this.chkAtInt.AutoSize = true;
			this.chkAtInt.Location = new System.Drawing.Point(7, 27);
			this.chkAtInt.Name = "chkAtInt";
			this.chkAtInt.Size = new System.Drawing.Size(94, 17);
			this.chkAtInt.TabIndex = 42;
			this.chkAtInt.Text = "At Intersection";
			this.chkAtInt.UseVisualStyleBackColor = true;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(172, 6);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(42, 13);
			this.label26.TabIndex = 41;
			this.label26.Text = "Road 1";
			// 
			// txtAIRoadName1
			// 
			this.txtAIRoadName1.Location = new System.Drawing.Point(220, 3);
			this.txtAIRoadName1.Name = "txtAIRoadName1";
			this.txtAIRoadName1.Size = new System.Drawing.Size(100, 20);
			this.txtAIRoadName1.TabIndex = 40;
			this.toolTip1.SetToolTip(this.txtAIRoadName1, "Road Name");
			// 
			// label34
			// 
			this.label34.AutoSize = true;
			this.label34.Location = new System.Drawing.Point(9, 10);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(29, 13);
			this.label34.TabIndex = 39;
			this.label34.Text = "Addr";
			// 
			// txtOIAddrNum
			// 
			this.txtOIAddrNum.Location = new System.Drawing.Point(44, 3);
			this.txtOIAddrNum.Name = "txtOIAddrNum";
			this.txtOIAddrNum.Size = new System.Drawing.Size(100, 20);
			this.txtOIAddrNum.TabIndex = 38;
			this.toolTip1.SetToolTip(this.txtOIAddrNum, "Address Num");
			// 
			// cbxTown
			// 
			this.cbxTown.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			this.cbxTown.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			this.cbxTown.FormattingEnabled = true;
			this.cbxTown.Location = new System.Drawing.Point(151, 3);
			this.cbxTown.Name = "cbxTown";
			this.cbxTown.Size = new System.Drawing.Size(177, 21);
			this.cbxTown.TabIndex = 1;
			this.toolTip1.SetToolTip(this.cbxTown, "Town");
			this.cbxTown.Enter += new System.EventHandler(this.cbx_Enter);
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.btnRevGeocode);
			this.tabPage1.Controls.Add(this.txtRevY);
			this.tabPage1.Controls.Add(this.txtRevX);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(497, 390);
			this.tabPage1.TabIndex = 4;
			this.tabPage1.Text = "Reverse";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(54, 60);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(14, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "Y";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(54, 33);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(14, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "X";
			// 
			// btnRevGeocode
			// 
			this.btnRevGeocode.Enabled = false;
			this.btnRevGeocode.Location = new System.Drawing.Point(74, 84);
			this.btnRevGeocode.Name = "btnRevGeocode";
			this.btnRevGeocode.Size = new System.Drawing.Size(126, 23);
			this.btnRevGeocode.TabIndex = 2;
			this.btnRevGeocode.Text = "Reverse Geocode";
			this.btnRevGeocode.UseVisualStyleBackColor = true;
			this.btnRevGeocode.Click += new System.EventHandler(this.btnRevGeocode_Click);
			// 
			// txtRevY
			// 
			this.txtRevY.Location = new System.Drawing.Point(74, 57);
			this.txtRevY.Name = "txtRevY";
			this.txtRevY.Size = new System.Drawing.Size(126, 20);
			this.txtRevY.TabIndex = 1;
			this.txtRevY.Enter += new System.EventHandler(this.txt_Enter);
			// 
			// txtRevX
			// 
			this.txtRevX.Location = new System.Drawing.Point(74, 30);
			this.txtRevX.Name = "txtRevX";
			this.txtRevX.Size = new System.Drawing.Size(126, 20);
			this.txtRevX.TabIndex = 0;
			this.txtRevX.Enter += new System.EventHandler(this.txt_Enter);
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.chkTesting);
			this.tabPage2.Controls.Add(this.btnSaveCandRoadAttr);
			this.tabPage2.Controls.Add(this.btnCommonAttrs);
			this.tabPage2.Controls.Add(this.btnTEGeocodeCrashId);
			this.tabPage2.Controls.Add(this.btnTELoadCrashNum);
			this.tabPage2.Controls.Add(this.label22);
			this.tabPage2.Controls.Add(this.txtCrashNum);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(497, 390);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Transaction";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// chkTesting
			// 
			this.chkTesting.AutoSize = true;
			this.chkTesting.Checked = true;
			this.chkTesting.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkTesting.Location = new System.Drawing.Point(72, 125);
			this.chkTesting.Name = "chkTesting";
			this.chkTesting.Size = new System.Drawing.Size(61, 17);
			this.chkTesting.TabIndex = 6;
			this.chkTesting.Text = "Testing";
			this.chkTesting.UseVisualStyleBackColor = true;
			// 
			// btnSaveCandRoadAttr
			// 
			this.btnSaveCandRoadAttr.Location = new System.Drawing.Point(72, 95);
			this.btnSaveCandRoadAttr.Name = "btnSaveCandRoadAttr";
			this.btnSaveCandRoadAttr.Size = new System.Drawing.Size(148, 23);
			this.btnSaveCandRoadAttr.TabIndex = 5;
			this.btnSaveCandRoadAttr.Text = "Get Cand Road Attrs";
			this.btnSaveCandRoadAttr.UseVisualStyleBackColor = true;
			this.btnSaveCandRoadAttr.Click += new System.EventHandler(this.btnSaveCandRoadAttr_Click);
			// 
			// btnCommonAttrs
			// 
			this.btnCommonAttrs.Enabled = false;
			this.btnCommonAttrs.Location = new System.Drawing.Point(72, 66);
			this.btnCommonAttrs.Name = "btnCommonAttrs";
			this.btnCommonAttrs.Size = new System.Drawing.Size(148, 23);
			this.btnCommonAttrs.TabIndex = 3;
			this.btnCommonAttrs.Text = "Get Common Attrs";
			this.btnCommonAttrs.UseVisualStyleBackColor = true;
			this.btnCommonAttrs.Click += new System.EventHandler(this.btnCommonAttrs_Click);
			// 
			// btnTEGeocodeCrashId
			// 
			this.btnTEGeocodeCrashId.Location = new System.Drawing.Point(72, 36);
			this.btnTEGeocodeCrashId.Name = "btnTEGeocodeCrashId";
			this.btnTEGeocodeCrashId.Size = new System.Drawing.Size(148, 23);
			this.btnTEGeocodeCrashId.TabIndex = 2;
			this.btnTEGeocodeCrashId.Text = "Batch Process CrashId";
			this.btnTEGeocodeCrashId.UseVisualStyleBackColor = true;
			this.btnTEGeocodeCrashId.Click += new System.EventHandler(this.btnTEGeocodeCrashId_Click);
			// 
			// btnTELoadCrashNum
			// 
			this.btnTELoadCrashNum.Location = new System.Drawing.Point(179, 7);
			this.btnTELoadCrashNum.Name = "btnTELoadCrashNum";
			this.btnTELoadCrashNum.Size = new System.Drawing.Size(75, 23);
			this.btnTELoadCrashNum.TabIndex = 1;
			this.btnTELoadCrashNum.Text = "Load";
			this.btnTELoadCrashNum.UseVisualStyleBackColor = true;
			this.btnTELoadCrashNum.Click += new System.EventHandler(this.btnTELoadCrashNum_Click);
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(6, 12);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(59, 13);
			this.label22.TabIndex = 1;
			this.label22.Text = "Crash Num";
			// 
			// txtCrashNum
			// 
			this.txtCrashNum.Location = new System.Drawing.Point(72, 10);
			this.txtCrashNum.Name = "txtCrashNum";
			this.txtCrashNum.Size = new System.Drawing.Size(100, 20);
			this.txtCrashNum.TabIndex = 0;
			this.txtCrashNum.Enter += new System.EventHandler(this.txt_Enter);
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.btnDecrypt);
			this.tabPage3.Controls.Add(this.btnEncrypt);
			this.tabPage3.Controls.Add(this.txtCrypt);
			this.tabPage3.Controls.Add(this.txtClear);
			this.tabPage3.Controls.Add(this.btnAItest);
			this.tabPage3.Controls.Add(this.btnReset);
			this.tabPage3.Controls.Add(this.label21);
			this.tabPage3.Controls.Add(this.btnReload);
			this.tabPage3.Controls.Add(this.btnSave);
			this.tabPage3.Controls.Add(this.dgvSettings);
			this.tabPage3.Controls.Add(this.cbxCfgGrp);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(497, 390);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Admin";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// btnDecrypt
			// 
			this.btnDecrypt.Enabled = false;
			this.btnDecrypt.Location = new System.Drawing.Point(211, 296);
			this.btnDecrypt.Name = "btnDecrypt";
			this.btnDecrypt.Size = new System.Drawing.Size(75, 23);
			this.btnDecrypt.TabIndex = 10;
			this.btnDecrypt.Text = "<- Decrypt";
			this.btnDecrypt.UseVisualStyleBackColor = true;
			this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
			// 
			// btnEncrypt
			// 
			this.btnEncrypt.Enabled = false;
			this.btnEncrypt.Location = new System.Drawing.Point(211, 266);
			this.btnEncrypt.Name = "btnEncrypt";
			this.btnEncrypt.Size = new System.Drawing.Size(75, 23);
			this.btnEncrypt.TabIndex = 9;
			this.btnEncrypt.Text = "Encrypt ->";
			this.btnEncrypt.UseVisualStyleBackColor = true;
			this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
			// 
			// txtCrypt
			// 
			this.txtCrypt.Location = new System.Drawing.Point(294, 265);
			this.txtCrypt.Multiline = true;
			this.txtCrypt.Name = "txtCrypt";
			this.txtCrypt.Size = new System.Drawing.Size(200, 122);
			this.txtCrypt.TabIndex = 8;
			// 
			// txtClear
			// 
			this.txtClear.Location = new System.Drawing.Point(4, 266);
			this.txtClear.Multiline = true;
			this.txtClear.Name = "txtClear";
			this.txtClear.Size = new System.Drawing.Size(200, 121);
			this.txtClear.TabIndex = 7;
			// 
			// btnAItest
			// 
			this.btnAItest.Enabled = false;
			this.btnAItest.Location = new System.Drawing.Point(294, 236);
			this.btnAItest.Name = "btnAItest";
			this.btnAItest.Size = new System.Drawing.Size(75, 23);
			this.btnAItest.TabIndex = 6;
			this.btnAItest.Text = "AI test";
			this.btnAItest.UseVisualStyleBackColor = true;
			this.btnAItest.Click += new System.EventHandler(this.btnAItest_Click);
			// 
			// btnReset
			// 
			this.btnReset.Enabled = false;
			this.btnReset.Location = new System.Drawing.Point(117, 236);
			this.btnReset.Name = "btnReset";
			this.btnReset.Size = new System.Drawing.Size(87, 23);
			this.btnReset.TabIndex = 5;
			this.btnReset.Text = "Global Reset";
			this.btnReset.UseVisualStyleBackColor = true;
			this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(4, 12);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(42, 13);
			this.label21.TabIndex = 4;
			this.label21.Text = "Module";
			// 
			// btnReload
			// 
			this.btnReload.Enabled = false;
			this.btnReload.Location = new System.Drawing.Point(4, 236);
			this.btnReload.Name = "btnReload";
			this.btnReload.Size = new System.Drawing.Size(75, 23);
			this.btnReload.TabIndex = 2;
			this.btnReload.Text = "Reload";
			this.btnReload.UseVisualStyleBackColor = true;
			this.btnReload.Click += new System.EventHandler(this.btnReload_Click);
			// 
			// btnSave
			// 
			this.btnSave.Enabled = false;
			this.btnSave.Location = new System.Drawing.Point(419, 236);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(75, 23);
			this.btnSave.TabIndex = 3;
			this.btnSave.Text = "Save";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// dgvSettings
			// 
			this.dgvSettings.AllowUserToAddRows = false;
			this.dgvSettings.AllowUserToDeleteRows = false;
			this.dgvSettings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvSettings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colName,
            this.colValue});
			this.dgvSettings.Location = new System.Drawing.Point(4, 32);
			this.dgvSettings.Name = "dgvSettings";
			this.dgvSettings.Size = new System.Drawing.Size(490, 198);
			this.dgvSettings.TabIndex = 1;
			// 
			// colName
			// 
			this.colName.HeaderText = "Name";
			this.colName.Name = "colName";
			// 
			// colValue
			// 
			this.colValue.HeaderText = "Value";
			this.colValue.Name = "colValue";
			// 
			// cbxCfgGrp
			// 
			this.cbxCfgGrp.FormattingEnabled = true;
			this.cbxCfgGrp.Location = new System.Drawing.Point(52, 5);
			this.cbxCfgGrp.Name = "cbxCfgGrp";
			this.cbxCfgGrp.Size = new System.Drawing.Size(240, 21);
			this.cbxCfgGrp.TabIndex = 0;
			this.cbxCfgGrp.SelectedIndexChanged += new System.EventHandler(this.cbxCfgGrp_SelectedIndexChanged);
			// 
			// txtOutput
			// 
			this.txtOutput.Location = new System.Drawing.Point(13, 435);
			this.txtOutput.Multiline = true;
			this.txtOutput.Name = "txtOutput";
			this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtOutput.Size = new System.Drawing.Size(505, 131);
			this.txtOutput.TabIndex = 57;
			// 
			// txtCrashDate
			// 
			this.txtCrashDate.Location = new System.Drawing.Point(421, 4);
			this.txtCrashDate.Name = "txtCrashDate";
			this.txtCrashDate.Size = new System.Drawing.Size(73, 20);
			this.txtCrashDate.TabIndex = 68;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(393, 6);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(24, 13);
			this.label6.TabIndex = 69;
			this.label6.Text = "Dte";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(532, 578);
			this.Controls.Add(this.txtOutput);
			this.Controls.Add(this.tabControl1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form1";
			this.Text = "Geocode Test Client";
			this.tabControl1.ResumeLayout(false);
			this.tabPage4.ResumeLayout(false);
			this.tabPage4.PerformLayout();
			this.tabControl2.ResumeLayout(false);
			this.tabNY.ResumeLayout(false);
			this.tabNY.PerformLayout();
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			this.tabPage3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvSettings)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

		#endregion

		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TextBox txtOutput;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.ComboBox cbxCfgGrp;
		private System.Windows.Forms.Button btnReload;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.DataGridView dgvSettings;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.ComboBox cbxTown;
		private System.Windows.Forms.TabControl tabControl2;
		private System.Windows.Forms.Button btnTELoadCrashNum;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.TextBox txtCrashNum;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.CheckBox chkMethodCoords;
		private System.Windows.Forms.CheckBox chkMethodRM;
		private System.Windows.Forms.CheckBox chkMethodLmrk;
		private System.Windows.Forms.CheckBox chkMethodMile;
		private System.Windows.Forms.CheckBox chkMethodExit;
		private System.Windows.Forms.CheckBox chkMethodAddr;
		private System.Windows.Forms.CheckBox chkMethodOffInt;
		private System.Windows.Forms.CheckBox chkMethodAtInt;
		private System.Windows.Forms.Button btnGeocode;
		private System.Windows.Forms.Label label58;
		private System.Windows.Forms.Button btnTest;
		private System.Windows.Forms.Label lblStatus;
		private System.Windows.Forms.Button btnReset;
		private System.Windows.Forms.DataGridViewTextBoxColumn colName;
		private System.Windows.Forms.DataGridViewTextBoxColumn colValue;
		private System.Windows.Forms.Button btnTEGeocode;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnRevGeocode;
		private System.Windows.Forms.TextBox txtRevY;
		private System.Windows.Forms.TextBox txtRevX;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnTEGeocodeCrashId;
		private System.Windows.Forms.Button btnAItest;
		private System.Windows.Forms.Button btnCommonAttrs;
		private System.Windows.Forms.Button btnSaveCandRoadAttr;
		private System.Windows.Forms.Button btnDecrypt;
		private System.Windows.Forms.Button btnEncrypt;
		private System.Windows.Forms.TextBox txtCrypt;
		private System.Windows.Forms.TextBox txtClear;
		private System.Windows.Forms.CheckBox chkTesting;
		private System.Windows.Forms.TextBox txtZIP;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cbxCounty;
		private System.Windows.Forms.TabPage tabNY;
		private System.Windows.Forms.CheckBox chkParking;
		private System.Windows.Forms.TextBox txtRMRefMark;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label48;
		private System.Windows.Forms.TextBox txtMMMile;
		private System.Windows.Forms.Label label56;
		private System.Windows.Forms.TextBox txtLMLandmark;
		private System.Windows.Forms.Label label51;
		private System.Windows.Forms.TextBox txtEXExit;
		private System.Windows.Forms.ComboBox cbxOffOpt;
		private System.Windows.Forms.ComboBox cbxOffUnit;
		private System.Windows.Forms.Label label35;
		private System.Windows.Forms.ComboBox cbxOIDir;
		private System.Windows.Forms.TextBox txtOIDist;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox txtAIRoadName2;
		private System.Windows.Forms.CheckBox chkAtInt;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox txtAIRoadName1;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.TextBox txtOIAddrNum;
		private System.Windows.Forms.Label label60;
		private System.Windows.Forms.Label label59;
		private System.Windows.Forms.TextBox txtGPSY;
		private System.Windows.Forms.TextBox txtGPSX;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtOIRoadName2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtCrashDate;
	}
}

